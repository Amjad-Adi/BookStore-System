package com.example.database;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {

    public List<Customer> getAllCustomers() {
        String sql = "SELECT * FROM Customers ORDER BY Customer_Id";
        List<Customer> list = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) list.add(mapRowToCustomer(rs));
            return list;

        } catch (SQLException e) {
            throw new RuntimeException("getAllCustomers failed: " + e.getMessage(), e);
        }
    }

    public int insertCustomer(Customer c) {
        String sql = """
            INSERT INTO Customers
            (
              Customer_First_Name,
              Customer_Second_Name,
              Customer_Email,
              Customer_Password,
              Customer_Profession,
              Customer_Birth_Date,
              Customer_Registration_Date,
              Customer_Activation_Date,
              Customer_Expiration_Date,
              budgetInDollars
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, c.getFirstName());
            ps.setString(2, c.getSecondName());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getPassword());

            if (c.getProfession() != null) ps.setString(5, c.getProfession());
            else ps.setNull(5, Types.VARCHAR);

            if (c.getBirthDate() != null) ps.setDate(6, Date.valueOf(c.getBirthDate()));
            else ps.setNull(6, Types.DATE);

            // NOT NULL in your SQL
            ps.setDate(7, Date.valueOf(c.getRegisterDate()));

            if (c.getActivationDate() != null) ps.setDate(8, Date.valueOf(c.getActivationDate()));
            else ps.setNull(8, Types.DATE);

            if (c.getExpirationDate() != null) ps.setDate(9, Date.valueOf(c.getExpirationDate()));
            else ps.setNull(9, Types.DATE);

            ps.setDouble(10, c.getBudgetInDollars());

            if (ps.executeUpdate() == 0) return -1;

            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getInt(1) : -1;
            }

        } catch (SQLIntegrityConstraintViolationException dup) {
            throw new RuntimeException("Email already exists.");
        } catch (SQLException e) {
            throw new RuntimeException("insertCustomer failed: " + e.getMessage(), e);
        }
    }

    public int updateCustomer(Customer c) {
        String sql = """
            UPDATE Customers SET
              Customer_First_Name=?,
              Customer_Second_Name=?,
              Customer_Email=?,
              Customer_Password=?,
              Customer_Profession=?,
              Customer_Birth_Date=?,
              Customer_Registration_Date=?,
              Customer_Activation_Date=?,
              Customer_Expiration_Date=?,
              budgetInDollars=?
            WHERE Customer_Id=?
            """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, c.getFirstName());
            ps.setString(2, c.getSecondName());
            ps.setString(3, c.getEmail());
            ps.setString(4, c.getPassword());

            if (c.getProfession() != null) ps.setString(5, c.getProfession());
            else ps.setNull(5, Types.VARCHAR);

            if (c.getBirthDate() != null) ps.setDate(6, Date.valueOf(c.getBirthDate()));
            else ps.setNull(6, Types.DATE);

            ps.setDate(7, Date.valueOf(c.getRegisterDate()));

            if (c.getActivationDate() != null) ps.setDate(8, Date.valueOf(c.getActivationDate()));
            else ps.setNull(8, Types.DATE);

            if (c.getExpirationDate() != null) ps.setDate(9, Date.valueOf(c.getExpirationDate()));
            else ps.setNull(9, Types.DATE);

            ps.setDouble(10, c.getBudgetInDollars());
            ps.setInt(11, c.getId());

            return ps.executeUpdate();

        } catch (SQLIntegrityConstraintViolationException dup) {
            throw new RuntimeException("Email already exists.");
        } catch (SQLException e) {
            throw new RuntimeException("updateCustomer failed: " + e.getMessage(), e);
        }
    }

    public boolean deleteCustomer(int id) {
        String sql = "DELETE FROM Customers WHERE Customer_Id=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, id);
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            throw new RuntimeException("deleteCustomer failed: " + e.getMessage(), e);
        }
    }

    private Customer mapRowToCustomer(ResultSet rs) throws SQLException {
        LocalDate birth = toLocal(rs.getDate("Customer_Birth_Date"));
        LocalDate reg   = toLocal(rs.getDate("Customer_Registration_Date"));
        LocalDate act   = toLocal(rs.getDate("Customer_Activation_Date"));
        LocalDate exp   = toLocal(rs.getDate("Customer_Expiration_Date"));

        double budget = rs.getDouble("budgetInDollars");
        if (rs.wasNull()) budget = 0.0;

        return new Customer(
                rs.getInt("Customer_Id"),
                rs.getString("Customer_First_Name"),
                rs.getString("Customer_Second_Name"),
                rs.getString("Customer_Email"),
                rs.getString("Customer_Password"),
                rs.getString("Customer_Profession"),
                birth,
                reg,
                act,
                exp,
                budget
        );
    }

    private LocalDate toLocal(Date d) {
        return d == null ? null : d.toLocalDate();
    }
}

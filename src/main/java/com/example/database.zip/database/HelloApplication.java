package com.example.database;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        URL fxml = HelloApplication.class.getResource("/com/example/database/CustomersView.fxml");
        if (fxml == null) throw new RuntimeException("FXML not found: /com/example/database/CustomersView.fxml");

        Scene scene = new Scene(FXMLLoader.load(fxml), 1200, 800);
        stage.setTitle("Book Store - Customers");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

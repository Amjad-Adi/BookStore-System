package com.example.database;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class CustomerController {

    // ===== Table =====
    @FXML private TableView<Customer> customersTable;
    @FXML private TableColumn<Customer, Integer> colId;
    @FXML private TableColumn<Customer, String> colFirst;
    @FXML private TableColumn<Customer, String> colSecond;
    @FXML private TableColumn<Customer, String> colEmail;
    @FXML private TableColumn<Customer, String> colProfession;
    @FXML private TableColumn<Customer, LocalDate> colBirth;
    @FXML private TableColumn<Customer, LocalDate> colReg;
    @FXML private TableColumn<Customer, LocalDate> colActivation;
    @FXML private TableColumn<Customer, LocalDate> colExpiration;
    @FXML private TableColumn<Customer, Double> colBudget;

    // ===== Labels =====
    @FXML private Label idLabel;
    @FXML private Label emailLabel;
    @FXML private Label passwordLabel;

    // ===== Form fields =====
    @FXML private TextField idField;
    @FXML private TextField firstNameField;
    @FXML private TextField secondNameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private TextField professionField;

    @FXML private DatePicker birthDatePicker;
    @FXML private DatePicker regDatePicker;
    @FXML private DatePicker activationDatePicker;
    @FXML private DatePicker expirationDatePicker;
    @FXML private TextField budgetField;

    // ===== Search =====
    @FXML private ComboBox<String> searchByCombo;
    @FXML private TextField searchField;

    // ===== Subscription =====
    @FXML private Label subscriptionLabel;
    @FXML private TextField subscriptionField;                 // VIEW
    @FXML private ComboBox<SubscriptionPlan> subscriptionCombo; // EDIT

    // ===== Buttons =====
    @FXML private Button confirmBtn;
    @FXML private Button cancelBtn;

    // ===== Status =====
    @FXML private Label statusLabel;

    private final ObservableList<Customer> customersList = FXCollections.observableArrayList();
    private final ObservableList<Customer> masterList = FXCollections.observableArrayList();
    private final CustomerDAO dao = new CustomerDAO();

    private enum Mode { VIEW, INSERT, UPDATE }
    private Mode mode = Mode.VIEW;

    // ✅ ONLY 3 plans (as you requested)
    private enum SubscriptionPlan {
        ONE_MONTH("1 Month", 30, 10.0),
        THREE_MONTHS("3 Months", 90, 20.0),
        ONE_YEAR("1 Year", 365, 30.0);

        final String label;
        final int days;
        final double gift;

        SubscriptionPlan(String label, int days, double gift) {
            this.label = label;
            this.days = days;
            this.gift = gift;
        }

        @Override public String toString() { return label; }
    }

    @FXML
    public void initialize() {
        // columns
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colFirst.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        colSecond.setCellValueFactory(new PropertyValueFactory<>("secondName"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colProfession.setCellValueFactory(new PropertyValueFactory<>("profession"));
        colBirth.setCellValueFactory(new PropertyValueFactory<>("birthDate"));
        colReg.setCellValueFactory(new PropertyValueFactory<>("registerDate"));
        colActivation.setCellValueFactory(new PropertyValueFactory<>("activationDate"));
        colExpiration.setCellValueFactory(new PropertyValueFactory<>("expirationDate"));
        colBudget.setCellValueFactory(new PropertyValueFactory<>("budgetInDollars"));

        customersTable.setItems(customersList);

        // row colors
        customersTable.setRowFactory(tv -> new TableRow<>() {
            @Override protected void updateItem(Customer item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) { setStyle(""); return; }

                boolean active = item.getExpirationDate() != null
                        && !item.getExpirationDate().isBefore(LocalDate.now());

                boolean odd = getIndex() % 2 == 1;
                String base = odd ? "rgba(15,23,42,0.65)" : "rgba(2,6,23,0.65)";
                String tint = active ? "rgba(34,197,94,0.18)" : "rgba(244,63,94,0.18)";

                if (isSelected()) setStyle("");
                else setStyle("-fx-background-color: " + base + ", " + tint + ";");
            }
        });

        // header visible
        customersTable.skinProperty().addListener((obs, o, n) -> {
            customersTable.lookupAll(".column-header .label").forEach(node ->
                    node.setStyle("-fx-text-fill: #e5e7eb; -fx-font-weight: bold;"));
        });

        customersTable.getSelectionModel().selectedItemProperty().addListener((obs, ov, c) -> {
            if (c != null) fillForm(c);
        });

        // search by
        searchByCombo.setItems(FXCollections.observableArrayList(
                "ID", "First Name", "Second Name", "Email", "Profession", "Active", "Expired"
        ));
        searchByCombo.getSelectionModel().select("First Name");

        // subscription combo (ONLY 3)
        subscriptionCombo.setItems(FXCollections.observableArrayList(SubscriptionPlan.values()));
        subscriptionCombo.getSelectionModel().select(SubscriptionPlan.ONE_MONTH);

        // budget rules
        budgetField.setText("0.0");
        budgetField.setEditable(false);
        budgetField.setDisable(false);

        // subscription change => update budget + dates (when editing)
        subscriptionCombo.valueProperty().addListener((obs, oldV, newV) -> applySubscriptionEffects(newV));

        // apply once
        applySubscriptionEffects(subscriptionCombo.getValue());

        // start in VIEW mode
        setMode(Mode.VIEW);
        loadCustomersSafe();
    }

    private void applySubscriptionEffects(SubscriptionPlan plan) {
        if (plan == null) {
            budgetField.setText("0.0");
            return;
        }

        // gift budget
        budgetField.setText(String.format("%.1f", plan.gift));

        // auto dates when editing
        if (mode == Mode.INSERT || mode == Mode.UPDATE) {
            LocalDate act = LocalDate.now();
            LocalDate exp = act.plusDays(plan.days);
            activationDatePicker.setValue(act);
            expirationDatePicker.setValue(exp);
        }
    }

    // ---------------- MODE ----------------
    private void setMode(Mode m) {
        this.mode = m;
        boolean editing = (m == Mode.INSERT || m == Mode.UPDATE);

        setFormDisabled(!editing);

        setNode(confirmBtn, editing);
        setNode(cancelBtn, editing);

        boolean showId = (m != Mode.INSERT);
        setNode(idLabel, showId);
        setNode(idField, showId);

        boolean showEmailPass = (m != Mode.UPDATE);
        setNode(emailLabel, showEmailPass);
        setNode(emailField, showEmailPass);
        setNode(passwordLabel, showEmailPass);
        setNode(passwordField, showEmailPass);

        setNode(subscriptionLabel, true);
        setNode(subscriptionField, !editing);
        setNode(subscriptionCombo, editing);

        if (m == Mode.INSERT) {
            clearForm();
            regDatePicker.setValue(LocalDate.now());
            subscriptionCombo.getSelectionModel().select(SubscriptionPlan.ONE_MONTH);
            applySubscriptionEffects(subscriptionCombo.getValue());
        }

        if (m == Mode.UPDATE) {
            applySubscriptionEffects(subscriptionCombo.getValue());
        }
    }

    private void setFormDisabled(boolean disabled) {
        firstNameField.setDisable(disabled);
        secondNameField.setDisable(disabled);
        emailField.setDisable(disabled);
        passwordField.setDisable(disabled);
        professionField.setDisable(disabled);

        birthDatePicker.setDisable(disabled);
        regDatePicker.setDisable(disabled);
        activationDatePicker.setDisable(disabled);
        expirationDatePicker.setDisable(disabled);

        // budget never editable by typing
        budgetField.setDisable(false);

        subscriptionCombo.setDisable(disabled);
        subscriptionField.setDisable(true);
    }

    private void setNode(Control c, boolean visible) {
        c.setVisible(visible);
        c.setManaged(visible);
    }

    // ---------------- LOAD ----------------
    private void loadCustomersSafe() {
        try {
            List<Customer> all = dao.getAllCustomers();
            masterList.setAll(all);
            customersList.setAll(all);
            setStatus("Loaded " + customersList.size() + " customers.");
        } catch (Exception e) {
            showError("Database error", e.getMessage());
            setStatus("Failed to load customers.");
            e.printStackTrace();
        }
    }

    // ---------------- FORM ----------------
    private void fillForm(Customer c) {
        idField.setText(String.valueOf(c.getId()));
        firstNameField.setText(nullToEmpty(c.getFirstName()));
        secondNameField.setText(nullToEmpty(c.getSecondName()));
        emailField.setText(nullToEmpty(c.getEmail()));
        passwordField.setText(nullToEmpty(c.getPassword()));
        professionField.setText(nullToEmpty(c.getProfession()));

        birthDatePicker.setValue(c.getBirthDate());
        regDatePicker.setValue(c.getRegisterDate());
        activationDatePicker.setValue(c.getActivationDate());
        expirationDatePicker.setValue(c.getExpirationDate());

        budgetField.setText(String.format("%.1f", c.getBudgetInDollars()));
        subscriptionField.setText(subscriptionText(c));
    }

    private String subscriptionText(Customer c) {
        if (c.getActivationDate() == null || c.getExpirationDate() == null) return "Not active";
        boolean active = !c.getExpirationDate().isBefore(LocalDate.now());
        return active ? ("Active (expires " + c.getExpirationDate() + ")")
                : ("Expired (" + c.getExpirationDate() + ")");
    }

    private void clearForm() {
        customersTable.getSelectionModel().clearSelection();
        idField.clear();
        firstNameField.clear();
        secondNameField.clear();
        emailField.clear();
        passwordField.clear();
        professionField.clear();
        birthDatePicker.setValue(null);
        regDatePicker.setValue(null);
        activationDatePicker.setValue(null);
        expirationDatePicker.setValue(null);

        budgetField.setText("0.0");
        subscriptionField.setText("");
    }

    // ---------------- BUTTONS ----------------

    @FXML
    private void onInsert() {
        setMode(Mode.INSERT);
        setStatus("INSERT mode: fill fields then CONFIRM.");
    }

    @FXML
    private void onUpdate() {
        Customer selected = customersTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a customer first."); return; }
        fillForm(selected);
        setMode(Mode.UPDATE);
        setStatus("UPDATE mode: edit fields then CONFIRM.");
    }

    @FXML
    private void onDelete() {
        Customer selected = customersTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a customer first."); return; }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Customer");
        alert.setHeaderText("Delete customer ID: " + selected.getId() + "?");
        alert.setContentText("Are you sure? This cannot be undone.");

        if (alert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) {
            setStatus("Delete canceled.");
            return;
        }

        try {
            boolean ok = dao.deleteCustomer(selected.getId());
            setStatus(ok ? "Deleted successfully." : "Delete failed.");
            loadCustomersSafe();
            setMode(Mode.VIEW);
        } catch (Exception e) {
            showError("Delete error", e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void onConfirm() {
        if (mode == Mode.INSERT) doInsert();
        else if (mode == Mode.UPDATE) doUpdate();
    }

    @FXML
    private void onCancel() {
        setMode(Mode.VIEW);
        setStatus("Canceled.");
    }

    private void doInsert() {
        String first = firstNameField.getText();
        String second = secondNameField.getText();
        String email = emailField.getText();
        String pass = passwordField.getText();
        String prof = professionField.getText();

        LocalDate birth = birthDatePicker.getValue();
        LocalDate reg = regDatePicker.getValue();

        if (isBlank(first) || isBlank(second) || isBlank(email) || isBlank(pass) || reg == null) {
            setStatus("Fill: First, Second, Email, Password, Reg Date.");
            return;
        }

        SubscriptionPlan plan = subscriptionCombo.getValue();
        if (plan == null) { setStatus("Choose subscription."); return; }

        double budget = plan.gift;
        LocalDate act = LocalDate.now();
        LocalDate exp = act.plusDays(plan.days);

        try {
            Customer c = new Customer(
                    first.trim(),
                    second.trim(),
                    email.trim(),
                    pass,
                    isBlank(prof) ? null : prof.trim(),
                    birth,
                    reg,
                    act,
                    exp,
                    budget
            );

            int newId = dao.insertCustomer(c);

            setStatus(newId > 0 ? ("Inserted customer ID = " + newId) : "Insert failed.");
            loadCustomersSafe();
            setMode(Mode.VIEW);

        } catch (Exception e) {
            showError("Insert error", e.getMessage());
            e.printStackTrace();
        }
    }

    private void doUpdate() {
        Customer selected = customersTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a customer first."); return; }

        String first = firstNameField.getText();
        String second = secondNameField.getText();
        String prof = professionField.getText();
        LocalDate birth = birthDatePicker.getValue();
        LocalDate reg = regDatePicker.getValue();

        if (isBlank(first) || isBlank(second) || reg == null) {
            setStatus("Fill: First, Second, Reg Date.");
            return;
        }

        SubscriptionPlan plan = subscriptionCombo.getValue();
        if (plan == null) { setStatus("Choose subscription."); return; }

        double budget = plan.gift;
        LocalDate act = LocalDate.now();
        LocalDate exp = act.plusDays(plan.days);

        try {
            Customer updated = new Customer(
                    selected.getId(),
                    first.trim(),
                    second.trim(),
                    selected.getEmail(),
                    selected.getPassword(),
                    isBlank(prof) ? null : prof.trim(),
                    birth,
                    reg,
                    act,
                    exp,
                    budget
            );

            int ok = dao.updateCustomer(updated);
            setStatus(ok > 0 ? "Updated successfully." : "Update failed.");
            loadCustomersSafe();
            setMode(Mode.VIEW);

        } catch (Exception e) {
            showError("Update error", e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void onSearch() {
        String by = searchByCombo.getValue();
        String key = (searchField.getText() == null) ? "" : searchField.getText().trim();

        Predicate<Customer> pred;

        switch (by) {
            case "ID" -> pred = c -> key.matches("\\d+") && c.getId() == Integer.parseInt(key);
            case "First Name" -> pred = c -> containsIgnoreCase(c.getFirstName(), key);
            case "Second Name" -> pred = c -> containsIgnoreCase(c.getSecondName(), key);
            case "Email" -> pred = c -> containsIgnoreCase(c.getEmail(), key);
            case "Profession" -> pred = c -> containsIgnoreCase(c.getProfession(), key);
            case "Active" -> pred = c -> c.getExpirationDate() != null && !c.getExpirationDate().isBefore(LocalDate.now());
            case "Expired" -> pred = c -> c.getExpirationDate() == null || c.getExpirationDate().isBefore(LocalDate.now());
            default -> pred = c -> true;
        }

        List<Customer> filtered = masterList.stream().filter(pred).collect(Collectors.toList());
        customersList.setAll(filtered);
        setStatus("Filtered: " + filtered.size());
    }

    @FXML
    private void onRefresh() {
        loadCustomersSafe();
        setMode(Mode.VIEW);
    }

    @FXML
    private void onClear() {
        clearForm();
        setMode(Mode.VIEW);
        setStatus("");
    }

    // ---------------- UTIL ----------------
    private boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }
    private String nullToEmpty(String s) { return s == null ? "" : s; }

    private boolean containsIgnoreCase(String value, String key) {
        if (key == null || key.isBlank()) return true;
        if (value == null) return false;
        return value.toLowerCase().contains(key.toLowerCase());
    }

    private void setStatus(String msg) { if (statusLabel != null) statusLabel.setText(msg); }

    private void showError(String title, String msg) {
        Alert a = new Alert(Alert.AlertType.ERROR, msg);
        a.setTitle(title);
        a.setHeaderText(title);
        a.showAndWait();
    }
}

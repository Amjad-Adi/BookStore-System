package com.example.database.Payment;
import com.example.database.DBConnection;

import java.sql.*;
import java.util.*;

public class PaymentPlanDAO {
    public static ArrayList<PaymentPlan> getPaymentPlanList() {
        String sqlSelectAllPlans = "Select * from Payment_Plan order by Payment_Plan_ID";
        try (Connection databaseConnection = DBConnection.getConnection();
             PreparedStatement preparedStatement = databaseConnection.prepareStatement(sqlSelectAllPlans);
             ResultSet sqlExecutionResult = preparedStatement.executeQuery()) {
            ArrayList<PaymentPlan> listOfPaymentPlans = new ArrayList<>();
            while (sqlExecutionResult.next()) {
                listOfPaymentPlans.add(new PaymentPlan(sqlExecutionResult.getInt("Payment_Plan_ID"), sqlExecutionResult.getInt("Payment_Plan_Period_In_Months"), sqlExecutionResult.wasNull()?null:sqlExecutionResult.getInt("Number_Of_Months_Before_The_Legal_Trial"), sqlExecutionResult.getString("Payment_Plan_Description")));
            }
            return listOfPaymentPlans;
        } catch (SQLException e) {
            throw new RuntimeException("getting Payment Plan List failed: " + e.getMessage(), e);
        }
    }

    public static int insertPaymentPlan(PaymentPlan paymentPlan){
        String sqlSelectAllPlans= """
            Insert into Payment_Plan (Payment_Plan_Period_In_Months,Number_Of_Months_Before_The_Legal_Trial,Payment_Plan_Description)
            values(?,?,?)""";
        try(Connection databaseConnection= DBConnection.getConnection();
            PreparedStatement preparedStatement=databaseConnection.prepareStatement(sqlSelectAllPlans, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setInt(1,paymentPlan.getPaymentPlanPeriodInMonths());
            if (paymentPlan.getNumberOfMonthsBeforeTheLegalTrial() == null)
                preparedStatement.setNull(2, Types.INTEGER);
            else preparedStatement.setInt(2,paymentPlan.getNumberOfMonthsBeforeTheLegalTrial());
            if (paymentPlan.getPaymentPlanDescription() != null)
                preparedStatement.setString(3, paymentPlan.getPaymentPlanDescription());
            else preparedStatement.setNull(3, Types.VARCHAR);
            if (preparedStatement.executeUpdate() == 0) return -1;
            try (ResultSet keys = preparedStatement.getGeneratedKeys()) {
                return keys.next() ? keys.getInt(1) : -1;
            }catch (SQLIntegrityConstraintViolationException duplicates) {
                throw new RuntimeException("Email already exists.");
            }
        }catch (SQLException e) {
            throw new RuntimeException("Inserting Payment Plan failed: " + e.getMessage(), e);
        }
    }

    public static void updatePaymentPlan(PaymentPlan paymentPlan) {
        String sql ="""
            UPDATE Payment_Plan 
            SET Payment_Plan_Period_In_Months=?,
                Number_Of_Months_Before_The_Legal_Trial=?,
                Payment_Plan_Description=?
            WHERE Payment_Plan_ID=?""";
        try (Connection databaseConnection = DBConnection.getConnection();
             PreparedStatement preparedStatement = databaseConnection.prepareStatement(sql)) {
            preparedStatement.setInt(1,paymentPlan.getPaymentPlanPeriodInMonths());
            if (paymentPlan.getNumberOfMonthsBeforeTheLegalTrial() == null)
                preparedStatement.setNull(2, Types.INTEGER);
            else preparedStatement.setInt(2,paymentPlan.getNumberOfMonthsBeforeTheLegalTrial());
            if (paymentPlan.getPaymentPlanDescription() != null) preparedStatement.setString(3, paymentPlan.getPaymentPlanDescription());
            else preparedStatement.setNull(3, Types.VARCHAR);
            preparedStatement.setInt(4, paymentPlan.getPaymentPlanID());
            preparedStatement.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException dup) {
            throw new RuntimeException("Id already exists.");
        } catch (SQLException e) {
            throw new RuntimeException("updateCustomer failed: " + e.getMessage(), e);
        }
    }
}
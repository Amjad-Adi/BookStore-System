package com.example.database.Payment;

public class PaymentPlan {
    private int paymentPlanID;
    private int paymentPlanPeriodInMonths;
    private Integer numberOfMonthsBeforeTheLegalTrial;
    private String paymentPlanDescription;

    public PaymentPlan(int paymentPlanID, int paymentPlanPeriodInMonths, Integer numberOfMonthsBeforeTheLegalTrial, String paymentPlanDescription) {
        this.paymentPlanID = paymentPlanID;
        this.paymentPlanPeriodInMonths = paymentPlanPeriodInMonths;
        this.numberOfMonthsBeforeTheLegalTrial = numberOfMonthsBeforeTheLegalTrial;
        this.paymentPlanDescription = paymentPlanDescription;
    }

    public int getPaymentPlanID() {
        return paymentPlanID;
    }

    public void setPaymentPlanID(int paymentPlanID) {
        this.paymentPlanID = paymentPlanID;
    }

    public int getPaymentPlanPeriodInMonths() {
        return paymentPlanPeriodInMonths;
    }

    public void setPaymentPlanPeriodInMonths(int paymentPlanPeriodInMonths) {
        this.paymentPlanPeriodInMonths = paymentPlanPeriodInMonths;
    }

    public Integer getNumberOfMonthsBeforeTheLegalTrial() {
        return numberOfMonthsBeforeTheLegalTrial;
    }

    public void setNumberOfMonthsBeforeTheLegalTrial(Integer numberOfMonthsBeforeTheLegalTrial) {
        this.numberOfMonthsBeforeTheLegalTrial = numberOfMonthsBeforeTheLegalTrial;
    }

    public String getPaymentPlanDescription() {
        return paymentPlanDescription;
    }

    public void setPaymentPlanDescription(String paymentPlanDescription) {
        this.paymentPlanDescription = paymentPlanDescription;
    }
}

package com.example.database.Payment;

import com.example.database.DBConnection;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.util.ArrayList;
import java.util.List;

import static javafx.collections.FXCollections.observableArrayList;

public class PaymentPlanController{
    //Labels
    @FXML private Label paymentPlanIDLabel;
    @FXML private Label paymentPlanPeriodInMonthsLabel;
    @FXML private Label numberOfMonthsBeforeTheLegalTrialLabel;
    @FXML private Label paymentPlanDescriptionLabel;
    //Text Fields to show and modify data
    @FXML
    private TextField paymentPlanIDField;
    @FXML private TextField paymentPlanPeriodInMonthsField;
    @FXML private TextField paymentPlanNumberOfMonthsBeforeTheLegalTrialField;
    @FXML private TextField paymentPlanDescriptionField;

    @FXML private Button confirmButton;
    @FXML private Button cancelButton;
    //Table and its columns
    @FXML
    private TableView<PaymentPlan> paymentPlanTable;
    @FXML private TableColumn<PaymentPlan, Integer> paymentPlanIDColumn;
    @FXML private TableColumn<PaymentPlan, Integer> paymentPlanPeriodInMonthsColumn;
    @FXML private TableColumn<PaymentPlan, Integer> numberOfMonthsBeforeTheLegalTrialColumn;
    @FXML private TableColumn<PaymentPlan, String> paymentPlanDescriptionColumn;

    private final ObservableList<PaymentPlan> paymentPlanList = observableArrayList();
    private final ObservableList<PaymentPlan> masterList    = observableArrayList();
    //show status
    @FXML private Label statusLabel;
    private enum Mode { VIEW, INSERT, UPDATE }
    private Mode mode = Mode.VIEW;
    private static final String ODD_ROW_COLOR  = "rgba(15,23,42,0.65)";
    private static final String EVEN_ROW_COLOR = "rgba(2,6,23,0.65)";
    private static final String SELECT_TINT    = "rgba(56,189,248,0.22)"; // نفس vibe

    //Search
    @FXML private ComboBox<String> searchByCombo;
    @FXML private TextField searchField;
    @FXML
    public void initialize(){ // used once when fxml loads
        paymentPlanTable.setItems(paymentPlanList);//sets the table to view the payment list
        paymentPlanIDColumn.setCellValueFactory(new PropertyValueFactory<>("paymentPlanID"));
        numberOfMonthsBeforeTheLegalTrialColumn.setCellValueFactory(new PropertyValueFactory<>("numberOfMonthsBeforeTheLegalTrial"));
        paymentPlanPeriodInMonthsColumn.setCellValueFactory(new PropertyValueFactory<>("paymentPlanPeriodInMonths"));
        numberOfMonthsBeforeTheLegalTrialColumn.setCellFactory(col -> new TableCell<>() {
            @Override
            protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? "" : item.toString());
            }
        });

        paymentPlanDescriptionColumn.setCellValueFactory(new PropertyValueFactory<>("paymentPlanDescription"));
        paymentPlanTable.setRowFactory(tv -> new TableRow<>() {
            @Override
            protected void updateItem(PaymentPlan paymentPlan, boolean empty) {
                super.updateItem(paymentPlan, empty);
                if (empty || paymentPlan == null) {
                    setStyle("");
                    return;
                }
                if (isSelected()) {
                    setStyle("");
                    return;
                }
                String baseColor = (getIndex() % 2 == 1) ? ODD_ROW_COLOR : EVEN_ROW_COLOR;
                if (isSelected()) {
                    setStyle("-fx-background-color: " + baseColor + ", " + SELECT_TINT + ";");
                } else {
                    setStyle("-fx-background-color: " + baseColor + ";");
                }
            }
        });
        paymentPlanTable.skinProperty().addListener((obs, o, n) -> paymentPlanTable.lookupAll(".column-header .label").forEach(
                node ->node.setStyle("-fx-text-fill: #e5e7eb; -fx-font-weight: bold;")));
        paymentPlanTable.getSelectionModel().selectedItemProperty().addListener((obs, ov, paymentPlan) -> {
            if (paymentPlan != null) fillForm(paymentPlan);
        });
        allowIntegerInputOnlyInFields(paymentPlanPeriodInMonthsField);
        allowIntegerInputOnlyInFields(paymentPlanNumberOfMonthsBeforeTheLegalTrialField);
        searchByCombo.setItems(observableArrayList("ID", "Period in month", "Number of months before legal trial", "Description"));
        searchByCombo.getSelectionModel().select("ID");
        setMode(Mode.VIEW);
        loadPaymentPlans();
    }

    private void fillForm(PaymentPlan paymentPlan) {
        paymentPlanIDField.setText(String.valueOf(paymentPlan.getPaymentPlanID()));
        paymentPlanPeriodInMonthsField.setText(String.valueOf(paymentPlan.getPaymentPlanPeriodInMonths()));
        paymentPlanNumberOfMonthsBeforeTheLegalTrialField.setText(paymentPlan.getNumberOfMonthsBeforeTheLegalTrial() == null ? "" : paymentPlan.getNumberOfMonthsBeforeTheLegalTrial().toString());
        paymentPlanDescriptionField.setText(paymentPlan.getPaymentPlanDescription() == null ? "" : paymentPlan.getPaymentPlanDescription());
    }


    private void setMode(Mode mode) {
        this.mode = mode;
        setNode(paymentPlanIDLabel, !(mode == Mode.INSERT));
        setNode(paymentPlanIDField, !(mode== Mode.INSERT));
        ChangeTextFieldMode(mode==Mode.VIEW);
        setNode(confirmButton, !(mode==Mode.VIEW));
        setNode(cancelButton, !(mode==Mode.VIEW));
    }
    private void ChangeTextFieldMode(boolean disable){
        paymentPlanPeriodInMonthsField.setDisable(disable);
        paymentPlanNumberOfMonthsBeforeTheLegalTrialField.setDisable(disable);
        paymentPlanDescriptionField.setDisable(disable);
    }

    private void setNode(Control c, boolean visible) {
        c.setVisible(visible);
        c.setManaged(visible);
    }

    private void loadPaymentPlans() {
        try {
            ArrayList<PaymentPlan> paymentPlans = PaymentPlanDAO.getPaymentPlanList();
            masterList.setAll(paymentPlans);
            paymentPlanList.setAll(paymentPlans);
            statusLabel.setText("Loaded " + paymentPlanList.size() + " payment plans.");
            paymentPlanTable.refresh();
        } catch (Exception e) {
            DBConnection.showError("Database error", e.getMessage());
            statusLabel.setText("Failed to load payment plans.");
            e.printStackTrace();
        }
    }

    @FXML
    private void onInsert() {
        clearForm();
        setMode(Mode.INSERT);
        statusLabel.setText("INSERT mode: fill fields then CONFIRM.");
    }

    private void insertPaymentPlan() {
        try {
            if (paymentPlanPeriodInMonthsField.getText().trim().isEmpty()) {
                statusLabel.setText("Period in months is required.");
                return;
            }
            PaymentPlan newPaymentPlan=new PaymentPlan(0,Integer.parseInt(paymentPlanPeriodInMonthsField.getText().trim()),paymentPlanNumberOfMonthsBeforeTheLegalTrialField.getText().trim().isEmpty() ? null : Integer.parseInt(paymentPlanNumberOfMonthsBeforeTheLegalTrialField.getText().trim()),(paymentPlanDescriptionField.getText() == null || paymentPlanDescriptionField.getText().trim().isEmpty()) ? null : paymentPlanDescriptionField.getText().trim());
            int newId = PaymentPlanDAO.insertPaymentPlan(newPaymentPlan);
            if (newId > 0) {
                PaymentPlan inserted = new PaymentPlan(newId, newPaymentPlan.getPaymentPlanPeriodInMonths(),  newPaymentPlan.getNumberOfMonthsBeforeTheLegalTrial(),newPaymentPlan.getPaymentPlanDescription());
                masterList.add(inserted);
                paymentPlanList.add(inserted);
                paymentPlanTable.getSelectionModel().select(inserted);
                setMode(Mode.VIEW);
                statusLabel.setText("Inserted payment plan ID = " + newId);
            } else {
                statusLabel.setText("Insert failed.");
            }
        } catch (Exception e) {
            DBConnection.showError("Insert error", e.getMessage());
            e.printStackTrace();
        }
    }

    private void allowIntegerInputOnlyInFields(TextField textField) {
        textField.setTextFormatter(new TextFormatter<>(change -> {
            String newText = change.getControlNewText();
            return newText.matches("\\d*") ? change : null;//allow digits or white spaces
        }));
    }

    @FXML
    private void onUpdate() {
        PaymentPlan selected = paymentPlanTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            statusLabel.setText("Select a payment Plan first.");
        }
        else {
            fillForm(selected);
            setMode(Mode.UPDATE);
            statusLabel.setText("UPDATE mode: edit fields then CONFIRM.");
        }
    }
    private void updatePaymentPlan() {
        PaymentPlan selected = paymentPlanTable.getSelectionModel().getSelectedItem();
        if (selected == null)
            statusLabel.setText("Select a payment plan first.");
        else {
            try {
                PaymentPlan updatedPaymentPlan = new PaymentPlan(Integer.parseInt(paymentPlanIDField.getText()), Integer.parseInt(paymentPlanPeriodInMonthsField.getText()),  paymentPlanNumberOfMonthsBeforeTheLegalTrialField.getText().trim().isEmpty() ? null : Integer.parseInt(paymentPlanNumberOfMonthsBeforeTheLegalTrialField.getText().trim()),(paymentPlanDescriptionField.getText() == null || paymentPlanDescriptionField.getText().trim().isEmpty()) ? null : paymentPlanDescriptionField.getText().trim());
                PaymentPlanDAO.updatePaymentPlan(updatedPaymentPlan);
                replaceInLists(updatedPaymentPlan);
                paymentPlanTable.getSelectionModel().select(updatedPaymentPlan);
                setMode(Mode.VIEW);
                statusLabel.setText("Updated successfully.");
            } catch (Exception e) {
                DBConnection.showError("Update error", e.getMessage());
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void onConfirm() {
        if (mode ==Mode.INSERT) {
            insertPaymentPlan();   // DO NOT swallow
        } else if (mode == Mode.UPDATE) {
            updatePaymentPlan();
        }
    }

    @FXML
    private void onCancel() {
        setMode(Mode.VIEW);
        statusLabel.setText("Canceled.");
    }

    @FXML
    private void onSearch() {
        String searchStandard = searchByCombo.getValue();
        String key = (searchField.getText() == null) ? "" : searchField.getText().trim();
        List<PaymentPlan> filtered = new ArrayList<>();
        for (PaymentPlan paymentPlan : masterList) {
            boolean ok=false;
            if ("ID".equals(searchStandard)) {
                ok = key.matches("\\d+") && paymentPlan.getPaymentPlanID()==Integer.parseInt(key);
            }
            else if ("Period in month".equals(searchStandard)) {
                ok = key.matches("\\d+") &&Integer.parseInt(key)==paymentPlan.getPaymentPlanPeriodInMonths();
            }
            else if ("Number of months before legal trial".equals(searchStandard)) {
                if (!key.matches("\\d+"))
                    ok = false;
                else {
                    Integer months = paymentPlan.getNumberOfMonthsBeforeTheLegalTrial();
                    ok = (months != null && months == Integer.parseInt(key));
                }
            }
            else if ("Description".equals(searchStandard)) {
                ok = key.equalsIgnoreCase(paymentPlan.getPaymentPlanDescription());
            }
            if (ok)
                filtered.add(paymentPlan);
        }
        paymentPlanList.setAll(filtered);
        statusLabel.setText("Filtered: " + filtered.size());
        paymentPlanTable.refresh();
    }

    @FXML
    private void onRefresh() {//return to initial
        paymentPlanList.setAll(masterList);
        setMode(Mode.VIEW);
        statusLabel.setText("Customers refreshed");
        paymentPlanTable.refresh();
    }
    private void clearForm() {
        paymentPlanTable.getSelectionModel().clearSelection();
        paymentPlanIDField.clear();
        paymentPlanPeriodInMonthsField.clear();
        paymentPlanNumberOfMonthsBeforeTheLegalTrialField.clear();
        paymentPlanDescriptionField.clear();
    }

    @FXML
    private void onClear() {
        clearForm();
        setMode(Mode.VIEW);
        statusLabel.setText("");
    }

    private void replaceInLists(PaymentPlan updatedPaymentPlan) {
        for (int i = 0; i< masterList.size();i++) {
            if (masterList.get(i).getPaymentPlanID() == updatedPaymentPlan.getPaymentPlanID()) {
                masterList.set(i, updatedPaymentPlan);
                break;
            }
        }
        for (int i = 0; i < paymentPlanList.size(); i++) {
            if (paymentPlanList.get(i).getPaymentPlanID() == updatedPaymentPlan.getPaymentPlanID()) {
                paymentPlanList.set(i, updatedPaymentPlan);
                break;
            }
        }
    }
}

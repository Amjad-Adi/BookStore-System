package com.example.database.Staff;

import java.time.LocalDate;

public class Staff {
    private int id;                 // Staff_ID
    private String firstName;       // First_Name
    private String lastName;        // Last_Name
    private String email;           // Staff_Email
    private String password;        // Staff_Password
    private double salary;          // Staff_Salary
    private LocalDate birthDate;    // Staff_Birth_Date
    private LocalDate hireDate;     // Staff_Hire_Date
    private String status;          // Staff_Status (Active/Inactive)

    // INSERT constructor (id auto)
    public Staff(String firstName, String lastName, String email, String password,
                 double salary, LocalDate birthDate, LocalDate hireDate, String status) {
        this(0, firstName, lastName, email, password, salary, birthDate, hireDate, status);
    }

    // READ/UPDATE/DELETE constructor
    public Staff(int id, String firstName, String lastName, String email, String password,
                 double salary, LocalDate birthDate, LocalDate hireDate, String status) {
        this.id = id;
        this.firstName = firstName;
        this.lastName  = lastName;
        this.email     = email;
        this.password  = password;
        this.salary    = salary;
        this.birthDate = birthDate;
        this.hireDate  = hireDate;
        this.status    = status;
    }

    public int getId() { return id; }
    public String getFirstName() { return firstName; }
    public String getLastName() { return lastName; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public double getSalary() { return salary; }
    public LocalDate getBirthDate() { return birthDate; }
    public LocalDate getHireDate() { return hireDate; }
    public String getStatus() { return status; }

    public void setId(int id) { this.id = id; }
    public void setFirstName(String firstName) { this.firstName = firstName; }
    public void setLastName(String lastName) { this.lastName = lastName; }
    public void setEmail(String email) { this.email = email; }
    public void setPassword(String password) { this.password = password; }
    public void setSalary(double salary) { this.salary = salary; }
    public void setBirthDate(LocalDate birthDate) { this.birthDate = birthDate; }
    public void setHireDate(LocalDate hireDate) { this.hireDate = hireDate; }
    public void setStatus(String status) { this.status = status; }
}

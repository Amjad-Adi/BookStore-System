package com.example.database;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.net.URL;

public class HelloApplication extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        SceneManager.setStage(stage);

        URL loginUrl = ResourceHelper.fxml("login.fxml");
        FXMLLoader loader = new FXMLLoader(loginUrl);

        Scene scene = new Scene(loader.load());
        stage.setTitle("Book Store");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}

package com.example.database.WareHouse;

public class WarehouseContact {
    private int contactId;         // Contact_ID
    private int warehouseId;       // Warehouse_ID
    private String contactNumber;  // Contact_Number

    public WarehouseContact(int contactId, int warehouseId, String contactNumber) {
        this.contactId = contactId;
        this.warehouseId = warehouseId;
        this.contactNumber = contactNumber;
    }

    // for creating before we know contactId
    public WarehouseContact(int warehouseId, String contactNumber) {
        this(0, warehouseId, contactNumber);
    }

    // for creating before we know warehouseId (insert mode)
    public WarehouseContact(String contactNumber) {
        this(0, 0, contactNumber);
    }

    public int getContactId() { return contactId; }
    public int getWarehouseId() { return warehouseId; }
    public String getContactNumber() { return contactNumber; }

    public void setWarehouseId(int warehouseId) { this.warehouseId = warehouseId; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }
}

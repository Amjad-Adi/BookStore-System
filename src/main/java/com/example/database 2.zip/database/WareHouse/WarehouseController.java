package com.example.database.WareHouse;

import com.example.database.DBConnection;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class WarehouseController {

    // Warehouses table
    @FXML private TableView<Warehouse> warehouseTable;
    @FXML private TableColumn<Warehouse, Integer> colId;
    @FXML private TableColumn<Warehouse, String> colName;
    @FXML private TableColumn<Warehouse, String> colAddress;
    @FXML private TableColumn<Warehouse, LocalDate> colEst;
    @FXML private TableColumn<Warehouse, Integer> colMax;
    @FXML private TableColumn<Warehouse, Integer> colCurrent;
    @FXML private TableColumn<Warehouse, Integer> colAvailable;

    @FXML private TextField availableStorageField;
    @FXML private ProgressBar utilizationBar;
    @FXML private Label utilizationLabel;
    @FXML private Label overviewLabel;

    // Search
    @FXML private ComboBox<String> searchByCombo;
    @FXML private TextField searchField;

    // Contacts table
    @FXML private TableView<WarehouseContact> contactsTable;
    @FXML private TableColumn<WarehouseContact, Integer> colContactId;
    @FXML private TableColumn<WarehouseContact, String> colContactNumber;

    // Header form
    @FXML private TextField idField;
    @FXML private TextField nameField;
    @FXML private TextField addressField;
    @FXML private DatePicker estDatePicker;
    @FXML private TextField maxStorageField;
    @FXML private TextField currentStorageField;

    // Contact add form
    @FXML private TextField contactNumberField;

    // Buttons + status
    @FXML private Button confirmBtn;
    @FXML private Button cancelBtn;
    @FXML private Label statusLabel;

    private final ObservableList<Warehouse> master = FXCollections.observableArrayList();
    private final ObservableList<Warehouse> table  = FXCollections.observableArrayList();
    private final ObservableList<WarehouseContact> currentContacts = FXCollections.observableArrayList();

    private enum Mode { VIEW, INSERT, UPDATE }
    private Mode mode = Mode.VIEW;

    @FXML
    public void initialize() {

        // ----------------- Table sizing / scroll behavior (YOUR CODE IDEA) -----------------
        warehouseTable.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);

        // Fixed “data” columns (stable and scalable)
        colId.setPrefWidth(80);
        colName.setPrefWidth(170);
        colEst.setPrefWidth(140);
        colMax.setPrefWidth(130);
        colCurrent.setPrefWidth(140);
        colAvailable.setPrefWidth(140);

        // Address: make it wide so horizontal bar appears on smaller screens
        colAddress.setMinWidth(450);
        colAddress.setPrefWidth(750);
        colAddress.setResizable(true);

        // Apply corner/filler styling (YOUR CODE IDEA)
        applyCornerAndFillerStyle(warehouseTable);

        // Contacts table (optional but nice)
        contactsTable.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        colContactId.setPrefWidth(120);
        colContactNumber.setMinWidth(260);
        colContactNumber.setPrefWidth(420);
        colContactNumber.setResizable(true);
        applyCornerAndFillerStyle(contactsTable);

        // ----------------- table columns mapping -----------------
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colAddress.setCellValueFactory(new PropertyValueFactory<>("address"));
        colEst.setCellValueFactory(new PropertyValueFactory<>("establishmentDate"));
        colMax.setCellValueFactory(new PropertyValueFactory<>("maxStorage"));
        colCurrent.setCellValueFactory(new PropertyValueFactory<>("currentStorage"));
        colAvailable.setCellValueFactory(new PropertyValueFactory<>("availableStorage"));

        warehouseTable.setItems(table);

        maxStorageField.textProperty().addListener((obs, o, n) -> liveRecalc());
        currentStorageField.textProperty().addListener((obs, o, n) -> liveRecalc());

        // contacts mapping
        colContactId.setCellValueFactory(new PropertyValueFactory<>("contactId"));
        colContactNumber.setCellValueFactory(new PropertyValueFactory<>("contactNumber"));
        contactsTable.setItems(currentContacts);

        // search
        searchByCombo.setItems(FXCollections.observableArrayList("ID", "Name", "Address"));
        searchByCombo.getSelectionModel().select("Name");

        idField.setEditable(false);

        loadWarehousesOnce();

        // row coloring
        warehouseTable.setRowFactory(tv -> new TableRow<Warehouse>() {
            @Override protected void updateItem(Warehouse w, boolean empty) {
                super.updateItem(w, empty);
                if (empty || w == null) { setStyle(""); return; }

                double ratio = (w.getMaxStorage() <= 0) ? 0 : (w.getCurrentStorage() / (double) w.getMaxStorage());

                if (ratio >= 0.9) {
                    setStyle("-fx-background-color: rgba(2,6,23,0.65), rgba(244,63,94,0.18);");
                } else if (ratio >= 0.7) {
                    setStyle("-fx-background-color: rgba(2,6,23,0.65), rgba(245,158,11,0.18);");
                } else {
                    setStyle("-fx-background-color: rgba(2,6,23,0.65), rgba(34,197,94,0.10);");
                }
            }
        });

        warehouseTable.getSelectionModel().selectedItemProperty().addListener((obs, ov, w) -> {
            if (w != null) {
                fillForm(w);
                loadContactsFor(w.getId());
                setMode(Mode.VIEW);
            }
        });

        clearAll();
        setMode(Mode.VIEW);
    }

    // YOUR skinProperty listener as a reusable helper
    private void applyCornerAndFillerStyle(TableView<?> tableView) {
        tableView.skinProperty().addListener((obs, oldSkin, newSkin) -> {
            Platform.runLater(() -> {
                Node corner = tableView.lookup(".corner");
                if (corner != null) {
                    corner.setStyle(
                            "-fx-background-color: #020617;" +
                                    "-fx-border-color: #1e293b;" +
                                    "-fx-border-width: 0 0 1 1;"
                    );
                }

                Node filler = tableView.lookup(".filler");
                if (filler != null) {
                    filler.setStyle(
                            "-fx-background-color: #020617;" +
                                    "-fx-border-color: #1e293b;" +
                                    "-fx-border-width: 0 0 1 0;"
                    );
                }
            });
        });
    }

    private void loadWarehousesOnce() {
        try {
            List<Warehouse> all = WarehouseDAO.getAllWarehouses();
            master.setAll(all);
            table.setAll(all);
            setStatus("Loaded " + all.size() + " warehouses.");
        } catch (Exception e) {
            DBConnection.showError("DB error", e.getMessage());
            setStatus("Failed to load warehouses.");
            e.printStackTrace();
        }
    }

    private void loadContactsFor(int warehouseId) {
        try {
            List<WarehouseContact> contacts = WarehouseDAO.getContactsByWarehouseId(warehouseId);
            currentContacts.setAll(contacts);
        } catch (Exception e) {
            DBConnection.showError("Contacts load error", e.getMessage());
            e.printStackTrace();
        }
    }

    private void updateUtilization(int max, int current) {
        int available = Math.max(0, max - current);
        availableStorageField.setText(String.valueOf(available));

        double ratio = (max <= 0) ? 0.0 : Math.min(1.0, Math.max(0.0, current / (double) max));
        utilizationBar.setProgress(ratio);
        utilizationLabel.setText(String.format("%.0f%%", ratio * 100));

        overviewLabel.setText("Available: " + available + " / " + max);
    }

    private void fillForm(Warehouse w) {
        idField.setText(String.valueOf(w.getId()));
        nameField.setText(nullToEmpty(w.getName()));
        addressField.setText(nullToEmpty(w.getAddress()));
        estDatePicker.setValue(w.getEstablishmentDate());
        maxStorageField.setText(String.valueOf(w.getMaxStorage()));
        currentStorageField.setText(String.valueOf(w.getCurrentStorage()));
        updateUtilization(w.getMaxStorage(), w.getCurrentStorage());
    }

    private void clearAll() {
        warehouseTable.getSelectionModel().clearSelection();
        idField.clear();
        nameField.clear();
        addressField.clear();
        estDatePicker.setValue(LocalDate.now());
        maxStorageField.clear();
        currentStorageField.clear();
        contactNumberField.clear();
        currentContacts.clear();

        // reset utilization UI
        updateUtilization(0, 0);
    }

    private void liveRecalc() {
        int max = parseIntSafe(maxStorageField.getText());
        int cur = parseIntSafe(currentStorageField.getText());
        updateUtilization(max, cur);
    }

    private int parseIntSafe(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception e) { return 0; }
    }

    private void setMode(Mode m) {
        mode = m;
        boolean editing = (m == Mode.INSERT || m == Mode.UPDATE);

        nameField.setDisable(!editing);
        addressField.setDisable(!editing);
        estDatePicker.setDisable(!editing);
        maxStorageField.setDisable(!editing);
        currentStorageField.setDisable(!editing);

        contactNumberField.setDisable(!editing);
        contactsTable.setDisable(false);

        confirmBtn.setVisible(editing);
        confirmBtn.setManaged(editing);
        cancelBtn.setVisible(editing);
        cancelBtn.setManaged(editing);

        if (m == Mode.INSERT) {
            clearAll();
            estDatePicker.setValue(LocalDate.now());
        }
    }

    // ---------- Top bar ----------
    @FXML
    private void onSearch() {
        String by = searchByCombo.getValue();
        String key = (searchField.getText() == null) ? "" : searchField.getText().trim();

        List<Warehouse> filtered = new ArrayList<>();
        for (Warehouse w : master) {
            boolean ok;
            if ("ID".equals(by)) {
                ok = key.matches("\\d+") && w.getId() == Integer.parseInt(key);
            } else if ("Name".equals(by)) {
                ok = containsIgnoreCase(w.getName(), key);
            } else if ("Address".equals(by)) {
                ok = containsIgnoreCase(w.getAddress(), key);
            } else ok = true;

            if (ok) filtered.add(w);
        }
        table.setAll(filtered);
        setStatus("Filtered: " + filtered.size());
    }

    @FXML
    private void onRefresh() {
        table.setAll(master);
        setMode(Mode.VIEW);
        setStatus("Warehouses refreshed.");
    }

    // ---------- Buttons ----------
    @FXML
    private void onInsert() {
        setMode(Mode.INSERT);
        setStatus("INSERT mode: fill fields, add contacts, then CONFIRM.");
    }

    @FXML
    private void onUpdate() {
        Warehouse selected = warehouseTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a warehouse first."); return; }
        setMode(Mode.UPDATE);
        setStatus("UPDATE mode: edit then CONFIRM.");
    }

    @FXML
    private void onDelete() {
        Warehouse selected = warehouseTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a warehouse first."); return; }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Warehouse");
        alert.setHeaderText("Delete warehouse ID: " + selected.getId() + "?");
        alert.setContentText("Contacts will be deleted too.");

        if (alert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) {
            setStatus("Delete canceled.");
            return;
        }

        try {
            boolean ok = WarehouseDAO.deleteWarehouse(selected.getId());
            if (ok) {
                master.removeIf(w -> w.getId() == selected.getId());
                table.removeIf(w -> w.getId() == selected.getId());
                clearAll();
                setMode(Mode.VIEW);
                setStatus("Deleted successfully.");
            } else setStatus("Delete failed.");
        } catch (Exception e) {
            DBConnection.showError("Delete error", e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void onClear() {
        clearAll();
        setMode(Mode.VIEW);
        setStatus("");
    }

    @FXML
    private void onCancel() {
        setMode(Mode.VIEW);
        setStatus("Canceled.");
    }

    @FXML
    private void onConfirm() {
        if (mode == Mode.INSERT) doInsert();
        else if (mode == Mode.UPDATE) doUpdate();
    }

    // ---------- Contacts ----------
    @FXML
    private void onAddContact() {
        if (mode == Mode.VIEW) { setStatus("Switch to INSERT/UPDATE to edit contacts."); return; }
        String num = contactNumberField.getText();
        if (num == null || num.trim().isEmpty()) { setStatus("Enter a contact number."); return; }

        for (WarehouseContact c : currentContacts) {
            if (c.getContactNumber() != null && c.getContactNumber().equals(num.trim())) {
                setStatus("Contact already exists.");
                return;
            }
        }
        currentContacts.add(new WarehouseContact(num.trim()));
        contactNumberField.clear();
        setStatus("Contact added.");
    }

    @FXML
    private void onRemoveContact() {
        if (mode == Mode.VIEW) { setStatus("Switch to INSERT/UPDATE to edit contacts."); return; }
        WarehouseContact selected = contactsTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a contact first."); return; }
        currentContacts.remove(selected);
        setStatus("Contact removed.");
    }

    private void doInsert() {
        String name = nameField.getText();
        String address = addressField.getText();
        LocalDate est = estDatePicker.getValue();
        String maxStr = maxStorageField.getText();
        String curStr = currentStorageField.getText();

        if (isBlank(name) || isBlank(address) || est == null || isBlank(maxStr) || isBlank(curStr)) {
            setStatus("Fill: Name, Address, Establishment Date, Max, Current.");
            return;
        }

        int max, cur;
        try { max = Integer.parseInt(maxStr.trim()); }
        catch (Exception e) { setStatus("Max Storage must be an integer."); return; }

        try { cur = Integer.parseInt(curStr.trim()); }
        catch (Exception e) { setStatus("Current Storage must be an integer."); return; }

        if (max < 0 || cur < 0) { setStatus("Storage values must be >= 0."); return; }
        if (cur > max) { setStatus("Current Storage cannot exceed Max Storage."); return; }

        Warehouse w = new Warehouse(name.trim(), address.trim(), est, max, cur);

        try {
            int newId = WarehouseDAO.insertWarehouseWithContacts(w, new ArrayList<>(currentContacts));
            if (newId > 0) {
                Warehouse inserted = new Warehouse(newId, w.getName(), w.getAddress(),
                        w.getEstablishmentDate(), w.getMaxStorage(), w.getCurrentStorage());
                master.add(inserted);
                table.add(inserted);
                warehouseTable.getSelectionModel().select(inserted);
                setMode(Mode.VIEW);
                setStatus("Inserted warehouse ID = " + newId);
                loadContactsFor(newId);
            } else setStatus("Insert failed.");
        } catch (Exception e) {
            DBConnection.showError("Insert error", e.getMessage());
            e.printStackTrace();
        }
    }

    private void doUpdate() {
        Warehouse selected = warehouseTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a warehouse first."); return; }

        String name = nameField.getText();
        String address = addressField.getText();
        LocalDate est = estDatePicker.getValue();
        String maxStr = maxStorageField.getText();
        String curStr = currentStorageField.getText();

        if (isBlank(name) || isBlank(address) || est == null || isBlank(maxStr) || isBlank(curStr)) {
            setStatus("Fill: Name, Address, Establishment Date, Max, Current.");
            return;
        }

        int max, cur;
        try { max = Integer.parseInt(maxStr.trim()); }
        catch (Exception e) { setStatus("Max Storage must be an integer."); return; }

        try { cur = Integer.parseInt(curStr.trim()); }
        catch (Exception e) { setStatus("Current Storage must be an integer."); return; }

        if (max < 0 || cur < 0) { setStatus("Storage values must be >= 0."); return; }
        if (cur > max) { setStatus("Current Storage cannot exceed Max Storage."); return; }

        Warehouse updated = new Warehouse(selected.getId(), name.trim(), address.trim(), est, max, cur);

        try {
            boolean ok = WarehouseDAO.updateWarehouseWithContacts(updated, new ArrayList<>(currentContacts));
            if (ok) {
                List<Warehouse> all = WarehouseDAO.getAllWarehouses();
                master.setAll(all);
                table.setAll(all);

                for (Warehouse w : table) {
                    if (w.getId() == updated.getId()) {
                        warehouseTable.getSelectionModel().select(w);
                        fillForm(w);
                        break;
                    }
                }

                setMode(Mode.VIEW);
                setStatus("Updated successfully.");
            } else setStatus("Update failed.");
        } catch (Exception e) {
            DBConnection.showError("Update error", e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }
    private String nullToEmpty(String s) { return s == null ? "" : s; }

    private boolean containsIgnoreCase(String value, String key) {
        if (key == null || key.isBlank()) return true;
        if (value == null) return false;
        return value.toLowerCase().contains(key.toLowerCase());
    }

    private void setStatus(String msg) {
        if (statusLabel != null) statusLabel.setText(msg);
    }
}

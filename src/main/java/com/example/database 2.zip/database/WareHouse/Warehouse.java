package com.example.database.WareHouse;

import java.time.LocalDate;

public class Warehouse {
    private int id;                    // Warehouse_ID
    private String name;               // Warehouse_Name
    private String address;            // Warehouse_Address
    private LocalDate establishmentDate; // WarehouseDate_Of_Establishment
    private int maxStorage;            // Warehouse_Max_Storage
    private int currentStorage;        // Warehouse_Current_Storage

    // INSERT
    public Warehouse(String name, String address, LocalDate establishmentDate, int maxStorage, int currentStorage) {
        this(0, name, address, establishmentDate, maxStorage, currentStorage);
    }

    // READ/UPDATE/DELETE
    public Warehouse(int id, String name, String address, LocalDate establishmentDate, int maxStorage, int currentStorage) {
        this.id = id;
        this.name = name;
        this.address = address;
        this.establishmentDate = establishmentDate;
        this.maxStorage = maxStorage;
        this.currentStorage = currentStorage;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getAddress() { return address; }
    public LocalDate getEstablishmentDate() { return establishmentDate; }
    public int getMaxStorage() { return maxStorage; }
    public int getCurrentStorage() { return currentStorage; }

    // useful computed value for UI
    public int getAvailableStorage() { return Math.max(0, maxStorage - currentStorage); }

    public void setName(String name) { this.name = name; }
    public void setAddress(String address) { this.address = address; }
    public void setEstablishmentDate(LocalDate establishmentDate) { this.establishmentDate = establishmentDate; }
    public void setMaxStorage(int maxStorage) { this.maxStorage = maxStorage; }
    public void setCurrentStorage(int currentStorage) { this.currentStorage = currentStorage; }
}

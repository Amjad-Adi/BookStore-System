package com.example.database.WareHouse;

import com.example.database.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class WarehouseDAO {

    // ---------------- Warehouses ----------------

    public static List<Warehouse> getAllWarehouses() {
        String sql = "SELECT * FROM Warehouse ORDER BY Warehouse_ID";
        List<Warehouse> list = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Warehouse(
                        rs.getInt("Warehouse_ID"),
                        rs.getString("Warehouse_Name"),
                        rs.getString("Warehouse_Address"),
                        toLocal(rs.getDate("WarehouseDate_Of_Establishment")),
                        rs.getInt("Warehouse_Max_Storage"),
                        rs.getInt("Warehouse_Current_Storage")
                ));
            }
            return list;

        } catch (SQLException e) {
            throw new RuntimeException("getAllWarehouses failed: " + e.getMessage(), e);
        }
    }

    public static boolean deleteWarehouse(int warehouseId) {
        // Warehouse_Contact has ON DELETE CASCADE so contacts delete automatically
        String sql = "DELETE FROM Warehouse WHERE Warehouse_ID=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, warehouseId);
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            throw new RuntimeException("deleteWarehouse failed: " + e.getMessage(), e);
        }
    }

    // ---------------- Contacts ----------------

    public static List<WarehouseContact> getContactsByWarehouseId(int warehouseId) {
        String sql = "SELECT * FROM Warehouse_Contact WHERE Warehouse_ID=? ORDER BY Contact_ID";
        List<WarehouseContact> list = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, warehouseId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new WarehouseContact(
                            rs.getInt("Contact_ID"),
                            rs.getInt("Warehouse_ID"),
                            rs.getString("Contact_Number")
                    ));
                }
            }
            return list;

        } catch (SQLException e) {
            throw new RuntimeException("getContactsByWarehouseId failed: " + e.getMessage(), e);
        }
    }

    // Insert warehouse + contacts together
    public static int insertWarehouseWithContacts(Warehouse w, List<WarehouseContact> contacts) {
        String insertWarehouse = """
            INSERT INTO Warehouse
            (Warehouse_Name, Warehouse_Address, WarehouseDate_Of_Establishment, Warehouse_Max_Storage, Warehouse_Current_Storage)
            VALUES (?, ?, ?, ?, ?)
            """;

        String insertContact = """
            INSERT INTO Warehouse_Contact (Warehouse_ID, Contact_Number)
            VALUES (?, ?)
            """;

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            int newId;

            // 1) insert warehouse
            try (PreparedStatement ps = con.prepareStatement(insertWarehouse, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, w.getName());
                ps.setString(2, w.getAddress());
                ps.setDate(3, Date.valueOf(w.getEstablishmentDate()));
                ps.setInt(4, w.getMaxStorage());
                ps.setInt(5, w.getCurrentStorage());

                if (ps.executeUpdate() == 0) { con.rollback(); return -1; }

                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (!keys.next()) { con.rollback(); return -1; }
                    newId = keys.getInt(1);
                }
            }

            // 2) insert contacts (if any)
            if (contacts != null && !contacts.isEmpty()) {
                try (PreparedStatement ps = con.prepareStatement(insertContact)) {
                    for (WarehouseContact c : contacts) {
                        String num = c.getContactNumber();
                        if (num == null || num.trim().isEmpty()) continue;
                        ps.setInt(1, newId);
                        ps.setString(2, num.trim());
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
            }

            con.commit();
            con.setAutoCommit(true);
            return newId;

        } catch (SQLException e) {
            throw new RuntimeException("insertWarehouseWithContacts failed: " + e.getMessage(), e);
        }
    }

    // Update warehouse + replace contacts (simple + correct)
    public static boolean updateWarehouseWithContacts(Warehouse w, List<WarehouseContact> contacts) {
        String updateWarehouse = """
            UPDATE Warehouse
            SET Warehouse_Name=?,
                Warehouse_Address=?,
                WarehouseDate_Of_Establishment=?,
                Warehouse_Max_Storage=?,
                Warehouse_Current_Storage=?
            WHERE Warehouse_ID=?
            """;

        String deleteContacts = "DELETE FROM Warehouse_Contact WHERE Warehouse_ID=?";

        String insertContact = """
            INSERT INTO Warehouse_Contact (Warehouse_ID, Contact_Number)
            VALUES (?, ?)
            """;

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            // 1) update header
            try (PreparedStatement ps = con.prepareStatement(updateWarehouse)) {
                ps.setString(1, w.getName());
                ps.setString(2, w.getAddress());
                ps.setDate(3, Date.valueOf(w.getEstablishmentDate()));
                ps.setInt(4, w.getMaxStorage());
                ps.setInt(5, w.getCurrentStorage());
                ps.setInt(6, w.getId());

                if (ps.executeUpdate() != 1) { con.rollback(); return false; }
            }

            // 2) delete old contacts
            try (PreparedStatement ps = con.prepareStatement(deleteContacts)) {
                ps.setInt(1, w.getId());
                ps.executeUpdate();
            }

            // 3) re-insert contacts
            if (contacts != null && !contacts.isEmpty()) {
                try (PreparedStatement ps = con.prepareStatement(insertContact)) {
                    for (WarehouseContact c : contacts) {
                        String num = c.getContactNumber();
                        if (num == null || num.trim().isEmpty()) continue;
                        ps.setInt(1, w.getId());
                        ps.setString(2, num.trim());
                        ps.addBatch();
                    }
                    ps.executeBatch();
                }
            }

            con.commit();
            con.setAutoCommit(true);
            return true;

        } catch (SQLException e) {
            throw new RuntimeException("updateWarehouseWithContacts failed: " + e.getMessage(), e);
        }
    }

    private static LocalDate toLocal(Date d) {
        return (d == null) ? null : d.toLocalDate();
    }
}

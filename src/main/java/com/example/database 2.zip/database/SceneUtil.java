package com.example.database;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

import java.net.URL;

public final class SceneUtil {
    private SceneUtil() {}

    public static Parent load(String fxmlName) {
        String path = "/com/example/database/" + fxmlName;
        URL url = SceneUtil.class.getResource(path);
        if (url == null) {
            throw new RuntimeException(
                    "FXML not found on classpath: " + path +
                            "\nPut it under: src/main/resources/com/example/database/" + fxmlName
            );
        }
        try {
            return FXMLLoader.load(url);
        } catch (Exception e) {
            throw new RuntimeException("Failed to load FXML: " + fxmlName, e);
        }
    }

    // ✅ Use from buttons: onAction="#something" -> receives ActionEvent
    public static void switchTo(ActionEvent event, String fxmlName, String title) {
        if (event == null || !(event.getSource() instanceof Node node)) {
            throw new IllegalArgumentException("switchTo(ActionEvent): event/source is null.");
        }
        switchTo(node, fxmlName, title);
    }

    // ✅ Use when you already have a node (Button/Hyperlink/etc)
    public static void switchTo(Node anyNodeInScene, String fxmlName, String title) {
        if (anyNodeInScene == null) {
            throw new IllegalArgumentException("switchTo(Node): node is null.");
        }
        Parent root = load(fxmlName);
        Stage stage = (Stage) anyNodeInScene.getScene().getWindow();
        stage.setTitle(title);
        stage.setScene(new Scene(root));
        stage.show();
    }

    // ✅ Load a view inside StackPane (Dashboard shell)
    public static Parent loadInto(StackPane container, String fxmlName) {
        if (container == null) throw new IllegalArgumentException("loadInto: container is null.");
        Parent root = load(fxmlName);
        container.getChildren().setAll(root);
        return root;
    }
}

package com.example.database.Customer;

import com.example.database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class CustomerController {

    // ---------------- Table ----------------
    @FXML private TableView<Customer> customersTable;

    // ✅ THESE MUST MATCH customers.fxml fx:id EXACTLY
    @FXML private TableColumn<Customer, Integer> id;
    @FXML private TableColumn<Customer, String> firstName;
    @FXML private TableColumn<Customer, String> secondName;
    @FXML private TableColumn<Customer, String> email;
    @FXML private TableColumn<Customer, String> profession;
    @FXML private TableColumn<Customer, LocalDate> birthDate;
    @FXML private TableColumn<Customer, LocalDate> registerDate;
    @FXML private TableColumn<Customer, LocalDate> activationDate;
    @FXML private TableColumn<Customer, LocalDate> expirationDate;
    @FXML private TableColumn<Customer, Double> budget;

    // row colors
    private static final String ODD_ROW_COLOR  = "rgba(15,23,42,0.65)";
    private static final String EVEN_ROW_COLOR = "rgba(2,6,23,0.65)";
    private static final String ACTIVE_TINT    = "rgba(34,197,94,0.18)";
    private static final String EXPIRED_TINT   = "rgba(244,63,94,0.18)";
    private static final String SELECT_TINT    = "rgba(56,189,248,0.22)";

    // ---------------- Labels ----------------
    @FXML private Label idLabel;
    @FXML private Label emailLabel;
    @FXML private Label passwordLabel;

    // ---------------- Form fields ----------------
    @FXML private TextField idField;
    @FXML private TextField firstNameField;
    @FXML private TextField secondNameField;
    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private TextField professionField;
    @FXML private DatePicker birthDatePicker;
    @FXML private DatePicker regDatePicker;
    @FXML private DatePicker activationDatePicker;
    @FXML private DatePicker expirationDatePicker;
    @FXML private TextField budgetField;

    // Search
    @FXML private ComboBox<String> searchByCombo;
    @FXML private TextField searchField;

    // Subscription
    @FXML private Label subscriptionLabel;
    @FXML private TextField subscriptionField;                  // VIEW
    @FXML private ComboBox<SubscriptionPlan> subscriptionCombo; // EDIT

    // Buttons
    @FXML private Button confirmBtn;
    @FXML private Button cancelBtn;

    // Status
    @FXML private Label statusLabel;

    private final ObservableList<Customer> customersList = FXCollections.observableArrayList();
    private final ObservableList<Customer> masterList    = FXCollections.observableArrayList();

    private boolean initialLoaded = false;

    private enum Mode { VIEW, INSERT, UPDATE }
    private Mode mode = Mode.VIEW;

    private enum SubscriptionPlan {
        ONE_MONTH("1 Month", 30, 10.0),
        THREE_MONTHS("3 Months", 90, 20.0),
        ONE_YEAR("1 Year", 365, 30.0);

        final String label;
        final int days;
        final double gift;

        SubscriptionPlan(String label, int days, double gift) {
            this.label = label;
            this.days = days;
            this.gift = gift;
        }
        @Override public String toString() { return label; }
    }

    @FXML
    public void initialize() {
        assertInjected();

        // ✅ mapping
        id.setCellValueFactory(new PropertyValueFactory<>("id"));
        firstName.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        secondName.setCellValueFactory(new PropertyValueFactory<>("secondName"));
        email.setCellValueFactory(new PropertyValueFactory<>("email"));
        profession.setCellValueFactory(new PropertyValueFactory<>("profession"));
        birthDate.setCellValueFactory(new PropertyValueFactory<>("birthDate"));
        registerDate.setCellValueFactory(new PropertyValueFactory<>("registerDate"));
        activationDate.setCellValueFactory(new PropertyValueFactory<>("activationDate"));
        expirationDate.setCellValueFactory(new PropertyValueFactory<>("expirationDate"));
        budget.setCellValueFactory(new PropertyValueFactory<>("budgetInDollars"));

        customersTable.setItems(customersList);

        // ✅ selection + tint (no “white” selection)
        customersTable.setRowFactory(tv -> new TableRow<>() {
            @Override
            protected void updateItem(Customer customer, boolean empty) {
                super.updateItem(customer, empty);
                if (empty || customer == null) { setStyle(""); return; }

                String baseColor = (getIndex() % 2 == 1) ? ODD_ROW_COLOR : EVEN_ROW_COLOR;

                boolean active = customer.getExpirationDate() != null &&
                        !customer.getExpirationDate().isBefore(LocalDate.now());
                String statusColor = active ? ACTIVE_TINT : EXPIRED_TINT;

                if (isSelected()) {
                    setStyle("-fx-background-color: " + baseColor + ", " + SELECT_TINT + ";");
                } else {
                    setStyle("-fx-background-color: " + baseColor + ", " + statusColor + ";");
                }
            }
        });

        customersTable.getSelectionModel().selectedItemProperty().addListener((obs, ov, c) -> {
            if (c != null) fillForm(c);
        });

        // search
        searchByCombo.setItems(FXCollections.observableArrayList(
                "ID", "First Name", "Second Name", "Email", "Profession", "Active", "Expired"
        ));
        searchByCombo.getSelectionModel().select("First Name");

        // subscription
        subscriptionCombo.setItems(FXCollections.observableArrayList(SubscriptionPlan.values()));
        subscriptionCombo.getSelectionModel().select(SubscriptionPlan.ONE_MONTH);

        subscriptionCombo.valueProperty().addListener((obs, oldV, newV) -> applySubscriptionEffects(newV));

        // ✅ IMPORTANT: NEVER disable these read-only fields (disabled -> white/gray skin)
        budgetField.setEditable(false);
        budgetField.setDisable(false);

        subscriptionField.setEditable(false);
        subscriptionField.setDisable(false);

        applyDarkInputs(); // ✅ fixes white/light skins for DatePicker/ComboBox too

        applySubscriptionEffects(subscriptionCombo.getValue());
        setMode(Mode.VIEW);

        if (!initialLoaded) loadCustomersOnce();
    }

    private void assertInjected() {
        if (customersTable == null) throw new RuntimeException("customersTable not injected");
        if (id == null) throw new RuntimeException("TableColumn fx:id=\"id\" not injected (FXML mismatch)");
        if (firstName == null) throw new RuntimeException("TableColumn fx:id=\"firstName\" not injected (FXML mismatch)");
        if (budget == null) throw new RuntimeException("TableColumn fx:id=\"budget\" not injected (FXML mismatch)");
    }

    // ✅ Force dark style so DatePicker/ComboBox don’t show white parts
    private void applyDarkInputs() {
        String darkField = "-fx-background-color:#020617; -fx-text-fill:#e5e7eb; -fx-border-color:#1e293b; -fx-border-radius:6; -fx-background-radius:6;";
        if (idField != null) idField.setStyle(darkField);
        if (firstNameField != null) firstNameField.setStyle(darkField);
        if (secondNameField != null) secondNameField.setStyle(darkField);
        if (emailField != null) emailField.setStyle(darkField);
        if (passwordField != null) passwordField.setStyle(darkField);
        if (professionField != null) professionField.setStyle(darkField);
        if (budgetField != null) budgetField.setStyle(darkField);
        if (subscriptionField != null) subscriptionField.setStyle(darkField);

        String darkPicker = "-fx-background-color:#020617; -fx-border-color:#1e293b; -fx-border-radius:6; -fx-background-radius:6;";
        if (birthDatePicker != null) birthDatePicker.setStyle(darkPicker);
        if (regDatePicker != null) regDatePicker.setStyle(darkPicker);
        if (activationDatePicker != null) activationDatePicker.setStyle(darkPicker);
        if (expirationDatePicker != null) expirationDatePicker.setStyle(darkPicker);

        String darkCombo = "-fx-background-color:#020617; -fx-border-color:#1e293b; -fx-border-radius:6; -fx-background-radius:6; -fx-text-fill:#e5e7eb;";
        if (searchByCombo != null) searchByCombo.setStyle(darkCombo);
        if (subscriptionCombo != null) subscriptionCombo.setStyle(darkCombo);
    }

    private void loadCustomersOnce() {
        if (initialLoaded) return;
        try {
            List<Customer> all = CustomerDAO.getAllCustomers();
            masterList.setAll(all);
            customersList.setAll(all);
            setStatus("Loaded " + customersList.size() + " customers.");
            initialLoaded = true;
        } catch (Exception e) {
            DBConnection.showError("Database error", e.getMessage());
            setStatus("Failed to load customers.");
            e.printStackTrace();
        }
    }

    private void applySubscriptionEffects(SubscriptionPlan plan) {
        if (plan == null) { budgetField.setText("0.0"); return; }

        budgetField.setText(String.format("%.1f", plan.gift));

        if (mode == Mode.INSERT || mode == Mode.UPDATE) {
            LocalDate act = LocalDate.now();
            LocalDate exp = act.plusDays(plan.days);
            activationDatePicker.setValue(act);
            expirationDatePicker.setValue(exp);
        }
    }

    private void setMode(Mode m) {
        this.mode = m;
        boolean editing = (m == Mode.INSERT || m == Mode.UPDATE);

        setFormDisabled(!editing);

        setNode(confirmBtn, editing);
        setNode(cancelBtn, editing);

        boolean showId = (m != Mode.INSERT);
        setNode(idLabel, showId);
        setNode(idField, showId);

        boolean showEmailPass = (m != Mode.UPDATE);
        setNode(emailLabel, showEmailPass);
        setNode(emailField, showEmailPass);
        setNode(passwordLabel, showEmailPass);
        setNode(passwordField, showEmailPass);

        setNode(subscriptionLabel, true);
        setNode(subscriptionField, !editing);
        setNode(subscriptionCombo, editing);

        if (m == Mode.INSERT) {
            clearForm();
            regDatePicker.setValue(LocalDate.now());
            subscriptionCombo.getSelectionModel().select(SubscriptionPlan.ONE_MONTH);
            applySubscriptionEffects(subscriptionCombo.getValue());
        }
        if (m == Mode.UPDATE) applySubscriptionEffects(subscriptionCombo.getValue());
    }

    private void setFormDisabled(boolean disabled) {
        firstNameField.setDisable(disabled);
        secondNameField.setDisable(disabled);
        emailField.setDisable(disabled);
        passwordField.setDisable(disabled);
        professionField.setDisable(disabled);

        birthDatePicker.setDisable(disabled);
        regDatePicker.setDisable(disabled);
        activationDatePicker.setDisable(disabled);
        expirationDatePicker.setDisable(disabled);

        // ✅ never disable these (avoid white)
        budgetField.setDisable(false);
        budgetField.setEditable(false);

        subscriptionField.setDisable(false);
        subscriptionField.setEditable(false);

        subscriptionCombo.setDisable(disabled);
    }

    private void setNode(Node n, boolean visible) {
        if (n == null) return;
        n.setVisible(visible);
        n.setManaged(visible);
    }

    private void fillForm(Customer c) {
        idField.setText(String.valueOf(c.getId()));
        firstNameField.setText(nullToEmpty(c.getFirstName()));
        secondNameField.setText(nullToEmpty(c.getSecondName()));
        emailField.setText(nullToEmpty(c.getEmail()));
        passwordField.setText(nullToEmpty(c.getPassword()));
        professionField.setText(nullToEmpty(c.getProfession()));

        birthDatePicker.setValue(c.getBirthDate());
        regDatePicker.setValue(c.getRegisterDate());
        activationDatePicker.setValue(c.getActivationDate());
        expirationDatePicker.setValue(c.getExpirationDate());

        budgetField.setText(String.format("%.1f", c.getBudgetInDollars()));
        subscriptionField.setText(subscriptionText(c));
    }

    private String subscriptionText(Customer c) {
        if (c.getActivationDate() == null || c.getExpirationDate() == null) return "Not active";
        boolean active = !c.getExpirationDate().isBefore(LocalDate.now());
        return active ? ("Active (expires " + c.getExpirationDate() + ")")
                : ("Expired (" + c.getExpirationDate() + ")");
    }

    private void clearForm() {
        customersTable.getSelectionModel().clearSelection();
        idField.clear();
        firstNameField.clear();
        secondNameField.clear();
        emailField.clear();
        passwordField.clear();
        professionField.clear();
        birthDatePicker.setValue(null);
        regDatePicker.setValue(null);
        activationDatePicker.setValue(null);
        expirationDatePicker.setValue(null);

        budgetField.setText("0.0");
        subscriptionField.setText("");
    }

    // ---------------- Buttons ----------------

    @FXML private void onInsert() {
        setMode(Mode.INSERT);
        setStatus("INSERT mode: fill fields then CONFIRM.");
    }

    @FXML private void onUpdate() {
        Customer selected = customersTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a customer first."); return; }
        fillForm(selected);
        setMode(Mode.UPDATE);
        setStatus("UPDATE mode: edit fields then CONFIRM.");
    }

    @FXML private void onDelete() {
        Customer selected = customersTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a customer first."); return; }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Customer");
        alert.setHeaderText("Delete customer ID: " + selected.getId() + "?");
        alert.setContentText("Are you sure? This cannot be undone.");

        if (alert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) {
            setStatus("Delete canceled.");
            return;
        }

        try {
            boolean ok = CustomerDAO.deleteCustomer(selected.getId());
            if (ok) {
                removeFromListsById(selected.getId());
                clearForm();
                setMode(Mode.VIEW);
                setStatus("Deleted successfully.");
            } else setStatus("Delete failed.");
        } catch (Exception e) {
            DBConnection.showError("Delete error", e.getMessage());
            setStatus("Delete error.");
            e.printStackTrace();
        }
    }

    @FXML private void onConfirm() {
        if (mode == Mode.INSERT) doInsert();
        else if (mode == Mode.UPDATE) doUpdate();
    }

    @FXML private void onCancel() {
        setMode(Mode.VIEW);
        setStatus("Canceled.");
    }

    @FXML private void onClear() {
        clearForm();
        setMode(Mode.VIEW);
        setStatus("");
    }

    @FXML private void onRefresh() {
        customersList.setAll(masterList);
        setMode(Mode.VIEW);
        setStatus("Customers refreshed");
    }

    @FXML private void onSearch() {
        String by = searchByCombo.getValue();
        String key = (searchField.getText() == null) ? "" : searchField.getText().trim();

        List<Customer> filtered = new ArrayList<>();
        for (Customer c : masterList) {
            boolean ok;
            if ("ID".equals(by)) {
                ok = key.matches("\\d+") && c.getId() == Integer.parseInt(key);
            } else if ("First Name".equals(by)) {
                ok = containsIgnoreCase(c.getFirstName(), key);
            } else if ("Second Name".equals(by)) {
                ok = containsIgnoreCase(c.getSecondName(), key);
            } else if ("Email".equals(by)) {
                ok = containsIgnoreCase(c.getEmail(), key);
            } else if ("Profession".equals(by)) {
                ok = containsIgnoreCase(c.getProfession(), key);
            } else if ("Active".equals(by)) {
                ok = c.getExpirationDate() != null && !c.getExpirationDate().isBefore(LocalDate.now());
            } else if ("Expired".equals(by)) {
                ok = c.getExpirationDate() == null || c.getExpirationDate().isBefore(LocalDate.now());
            } else ok = true;

            if (ok) filtered.add(c);
        }

        customersList.setAll(filtered);
        setStatus("Filtered: " + filtered.size());
    }

    private void doInsert() {
        String first = txt(firstNameField);
        String second = txt(secondNameField);
        String emailTxt = txt(emailField);
        String pass = passwordField.getText() == null ? "" : passwordField.getText().trim();
        String prof = txt(professionField);

        LocalDate birth = birthDatePicker.getValue();
        LocalDate reg = regDatePicker.getValue();

        if (isBlank(first) || isBlank(second) || isBlank(emailTxt) || isBlank(pass) || reg == null) {
            setStatus("Fill: First, Second, Email, Password, Reg Date.");
            return;
        }

        SubscriptionPlan plan = subscriptionCombo.getValue();
        if (plan == null) { setStatus("Choose subscription."); return; }

        double bud = plan.gift;
        LocalDate act = LocalDate.now();
        LocalDate exp = act.plusDays(plan.days);

        try {
            Customer c = new Customer(0, first, second, emailTxt, pass,
                    isBlank(prof) ? null : prof, birth, reg, act, exp, bud);

            int newId = CustomerDAO.insertCustomer(c);

            if (newId > 0) {
                Customer inserted = new Customer(newId, c.getFirstName(), c.getSecondName(),
                        c.getEmail(), c.getPassword(), c.getProfession(),
                        c.getBirthDate(), c.getRegisterDate(), c.getActivationDate(),
                        c.getExpirationDate(), c.getBudgetInDollars());

                masterList.add(inserted);
                customersList.add(inserted);

                customersTable.getSelectionModel().select(inserted);
                setMode(Mode.VIEW);
                setStatus("Inserted customer ID = " + newId);
            } else setStatus("Insert failed.");

        } catch (Exception e) {
            DBConnection.showError("Insert error", e.getMessage());
            setStatus("Insert error.");
            e.printStackTrace();
        }
    }

    private void doUpdate() {
        Customer selected = customersTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a customer first."); return; }

        String idTxt = txt(idField);
        String first = txt(firstNameField);
        String second = txt(secondNameField);
        String prof = txt(professionField);

        LocalDate birth = birthDatePicker.getValue();
        LocalDate reg = regDatePicker.getValue();

        if (isBlank(first) || isBlank(second) || reg == null) {
            setStatus("Fill: First, Second, Reg Date.");
            return;
        }

        SubscriptionPlan plan = subscriptionCombo.getValue();
        if (plan == null) { setStatus("Choose subscription."); return; }

        double bud = plan.gift;
        LocalDate act = LocalDate.now();
        LocalDate exp = act.plusDays(plan.days);

        try {
            Customer updated = new Customer(Integer.parseInt(idTxt), first, second,
                    selected.getEmail(), selected.getPassword(), prof, birth, reg, act, exp, bud);

            boolean ok = CustomerDAO.updateCustomer(updated);

            if (ok) {
                replaceInLists(updated);
                customersTable.getSelectionModel().select(updated);
                setMode(Mode.VIEW);
                setStatus("Updated successfully.");
            } else setStatus("Update failed.");

        } catch (Exception e) {
            DBConnection.showError("Update error", e.getMessage());
            setStatus("Update error.");
            e.printStackTrace();
        }
    }

    private void removeFromListsById(int id) {
        masterList.removeIf(c -> c.getId() == id);
        customersList.removeIf(c -> c.getId() == id);
    }

    private void replaceInLists(Customer updated) {
        for (int i = 0; i < masterList.size(); i++) {
            if (masterList.get(i).getId() == updated.getId()) {
                masterList.set(i, updated);
                break;
            }
        }
        for (int i = 0; i < customersList.size(); i++) {
            if (customersList.get(i).getId() == updated.getId()) {
                customersList.set(i, updated);
                break;
            }
        }
    }

    private boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }
    private String txt(TextField t) { return (t == null || t.getText() == null) ? "" : t.getText().trim(); }
    private String nullToEmpty(String s) { return s == null ? "" : s; }

    private boolean containsIgnoreCase(String value, String key) {
        if (key == null || key.isBlank()) return true;
        if (value == null) return false;
        return value.toLowerCase().contains(key.toLowerCase());
    }

    private void setStatus(String msg) {
        if (statusLabel != null) statusLabel.setText(msg);
    }
}

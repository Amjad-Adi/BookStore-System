package com.example.database.Orders;

import java.time.LocalDate;

public class Order {
    private int id; // Transaction_ID
    private LocalDate date; // Transaction_Date
    private String channel; // Transaction_Channel
    private String information; // Transaction_Information
    private double cost; // Cost
    private double amountPaid; // Amount_Paid
    private String paymentStatus; // Payment_Status

    private Integer customerId; // Customer_ID
    private Integer paymentMethodId; // Payment_Method_Id

    // INSERT
    public Order(LocalDate date, String channel, String information,
                 double cost, double amountPaid, String paymentStatus,
                 Integer customerId, Integer paymentMethodId) {
        this(0, date, channel, information, cost, amountPaid, paymentStatus, customerId, paymentMethodId);
    }

    // READ/UPDATE/DELETE
    public Order(int id, LocalDate date, String channel, String information,
                 double cost, double amountPaid, String paymentStatus,
                 Integer customerId, Integer paymentMethodId) {
        this.id = id;
        this.date = date;
        this.channel = channel;
        this.information = information;
        this.cost = cost;
        this.amountPaid = amountPaid;
        this.paymentStatus = paymentStatus;
        this.customerId = customerId;
        this.paymentMethodId = paymentMethodId;
    }

    public int getId() { return id; }
    public LocalDate getDate() { return date; }
    public String getChannel() { return channel; }
    public String getInformation() { return information; }
    public double getCost() { return cost; }
    public double getAmountPaid() { return amountPaid; }
    public String getPaymentStatus() { return paymentStatus; }
    public Integer getCustomerId() { return customerId; }
    public Integer getPaymentMethodId() { return paymentMethodId; }

    public void setDate(LocalDate date) { this.date = date; }
    public void setChannel(String channel) { this.channel = channel; }
    public void setInformation(String information) { this.information = information; }
    public void setCost(double cost) { this.cost = cost; }
    public void setAmountPaid(double amountPaid) { this.amountPaid = amountPaid; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }
    public void setCustomerId(Integer customerId) { this.customerId = customerId; }
    public void setPaymentMethodId(Integer paymentMethodId) { this.paymentMethodId = paymentMethodId; }
}

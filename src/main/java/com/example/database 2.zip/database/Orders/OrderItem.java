package com.example.database.Orders;

public class OrderItem {
    private int orderId;       // Transaction_ID
    private int productId;     // Product_ID
    private String productName; // UI only (from join)
    private int quantity;      // Quantity
    private double priceAtTime; // Price_At_Time

    public OrderItem(int orderId, int productId, String productName, int quantity, double priceAtTime) {
        this.orderId = orderId;
        this.productId = productId;
        this.productName = productName;
        this.quantity = quantity;
        this.priceAtTime = priceAtTime;
    }

    // build before orderId exists
    public OrderItem(int productId, String productName, int quantity, double priceAtTime) {
        this(0, productId, productName, quantity, priceAtTime);
    }

    public int getOrderId() { return orderId; }
    public int getProductId() { return productId; }
    public String getProductName() { return productName; }
    public int getQuantity() { return quantity; }
    public double getPriceAtTime() { return priceAtTime; }
    public double getLineTotal() { return quantity * priceAtTime; }

    public void setOrderId(int orderId) { this.orderId = orderId; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
    public void setPriceAtTime(double priceAtTime) { this.priceAtTime = priceAtTime; }
}

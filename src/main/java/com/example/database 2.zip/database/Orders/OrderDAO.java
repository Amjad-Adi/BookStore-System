package com.example.database.Orders;

import com.example.database.DBConnection;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {

    // ---------- Orders ----------
    public static List<Order> getAllOrders() {
        String sql = "SELECT * FROM `Transaction` ORDER BY Transaction_ID DESC";
        List<Order> list = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Integer customerId = (Integer) rs.getObject("Customer_ID");
                Integer paymentId  = (Integer) rs.getObject("Payment_Method_Id");

                list.add(new Order(
                        rs.getInt("Transaction_ID"),
                        toLocal(rs.getDate("Transaction_Date")),
                        rs.getString("Transaction_Channel"),
                        rs.getString("Transaction_Information"),
                        rs.getDouble("Cost"),
                        rs.getDouble("Amount_Paid"),
                        rs.getString("Payment_Status"),
                        customerId,
                        paymentId
                ));
            }
            return list;

        } catch (SQLException e) {
            throw new RuntimeException("getAllOrders failed: " + e.getMessage(), e);
        }
    }

    public static boolean deleteOrder(int orderId) {
        String sql = "DELETE FROM `Transaction` WHERE Transaction_ID=?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            return ps.executeUpdate() == 1;
        } catch (SQLException e) {
            throw new RuntimeException("deleteOrder failed: " + e.getMessage(), e);
        }
    }

    // ---------- Items ----------
    public static List<OrderItem> getItems(int orderId) {
        String sql = """
            SELECT ti.Transaction_ID, ti.Product_ID, p.Product_Name, ti.Quantity, ti.Price_At_Time
            FROM Transaction_Items ti
            JOIN Product p ON p.Product_ID = ti.Product_ID
            WHERE ti.Transaction_ID=?
            ORDER BY ti.Product_ID
            """;

        List<OrderItem> items = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, orderId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    items.add(new OrderItem(
                            rs.getInt("Transaction_ID"),
                            rs.getInt("Product_ID"),
                            rs.getString("Product_Name"),
                            rs.getInt("Quantity"),
                            rs.getDouble("Price_At_Time")
                    ));
                }
            }

            return items;

        } catch (SQLException e) {
            throw new RuntimeException("getItems failed: " + e.getMessage(), e);
        }
    }

    // Insert order + items in one transaction
    public static int insertOrderWithItems(Order header, List<OrderItem> items) {
        String insertOrder = """
            INSERT INTO `Transaction`
            (Transaction_Date, Transaction_Channel, Transaction_Information, Cost, Amount_Paid, Payment_Status, Customer_ID, Payment_Method_Id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;

        String insertItem = """
            INSERT INTO Transaction_Items (Transaction_ID, Product_ID, Quantity, Price_At_Time)
            VALUES (?, ?, ?, ?)
            """;

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            // compute cost from items
            double total = 0;
            for (OrderItem it : items) total += it.getLineTotal();
            header.setCost(total);

            int newId;

            // insert header
            try (PreparedStatement ps = con.prepareStatement(insertOrder, Statement.RETURN_GENERATED_KEYS)) {
                ps.setDate(1, Date.valueOf(header.getDate()));
                ps.setString(2, header.getChannel());

                if (header.getInformation() != null) ps.setString(3, header.getInformation());
                else ps.setNull(3, Types.VARCHAR);

                ps.setDouble(4, header.getCost());
                ps.setDouble(5, header.getAmountPaid());
                ps.setString(6, header.getPaymentStatus());

                if (header.getCustomerId() != null) ps.setInt(7, header.getCustomerId());
                else ps.setNull(7, Types.INTEGER);

                if (header.getPaymentMethodId() != null) ps.setInt(8, header.getPaymentMethodId());
                else ps.setNull(8, Types.INTEGER);

                if (ps.executeUpdate() == 0) { con.rollback(); return -1; }

                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (!keys.next()) { con.rollback(); return -1; }
                    newId = keys.getInt(1);
                }
            }

            // insert items
            try (PreparedStatement ps = con.prepareStatement(insertItem)) {
                for (OrderItem it : items) {
                    ps.setInt(1, newId);
                    ps.setInt(2, it.getProductId());
                    ps.setInt(3, it.getQuantity());
                    ps.setDouble(4, it.getPriceAtTime());
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            con.commit();
            con.setAutoCommit(true);
            return newId;

        } catch (SQLException e) {
            throw new RuntimeException("insertOrderWithItems failed: " + e.getMessage(), e);
        }
    }

    // Update order header + replace all items (simple + correct)
    public static boolean updateOrderWithItems(Order header, List<OrderItem> items) {
        String updateOrder = """
            UPDATE `Transaction`
            SET Transaction_Date=?,
                Transaction_Channel=?,
                Transaction_Information=?,
                Cost=?,
                Amount_Paid=?,
                Payment_Status=?,
                Customer_ID=?,
                Payment_Method_Id=?
            WHERE Transaction_ID=?
            """;

        String deleteItems = "DELETE FROM Transaction_Items WHERE Transaction_ID=?";

        String insertItem = """
            INSERT INTO Transaction_Items (Transaction_ID, Product_ID, Quantity, Price_At_Time)
            VALUES (?, ?, ?, ?)
            """;

        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);

            // recompute cost
            double total = 0;
            for (OrderItem it : items) total += it.getLineTotal();
            header.setCost(total);

            // update header
            try (PreparedStatement ps = con.prepareStatement(updateOrder)) {
                ps.setDate(1, Date.valueOf(header.getDate()));
                ps.setString(2, header.getChannel());

                if (header.getInformation() != null) ps.setString(3, header.getInformation());
                else ps.setNull(3, Types.VARCHAR);

                ps.setDouble(4, header.getCost());
                ps.setDouble(5, header.getAmountPaid());
                ps.setString(6, header.getPaymentStatus());

                if (header.getCustomerId() != null) ps.setInt(7, header.getCustomerId());
                else ps.setNull(7, Types.INTEGER);

                if (header.getPaymentMethodId() != null) ps.setInt(8, header.getPaymentMethodId());
                else ps.setNull(8, Types.INTEGER);

                ps.setInt(9, header.getId());

                if (ps.executeUpdate() != 1) { con.rollback(); return false; }
            }

            // delete old items
            try (PreparedStatement ps = con.prepareStatement(deleteItems)) {
                ps.setInt(1, header.getId());
                ps.executeUpdate();
            }

            // insert new items
            try (PreparedStatement ps = con.prepareStatement(insertItem)) {
                for (OrderItem it : items) {
                    ps.setInt(1, header.getId());
                    ps.setInt(2, it.getProductId());
                    ps.setInt(3, it.getQuantity());
                    ps.setDouble(4, it.getPriceAtTime());
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            con.commit();
            con.setAutoCommit(true);
            return true;

        } catch (SQLException e) {
            throw new RuntimeException("updateOrderWithItems failed: " + e.getMessage(), e);
        }
    }

    private static LocalDate toLocal(Date d) {
        return (d == null) ? null : d.toLocalDate();
    }
}

package com.example.database.Orders;

import com.example.database.DBConnection;
import com.example.database.Customer.Customer;
import com.example.database.Customer.CustomerDAO;
import com.example.database.Payment.PaymentMethod;
import com.example.database.Payment.PaymentMethodDAO;
import com.example.database.Products.Product;
import com.example.database.Products.ProductDAO;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class OrderController {

    // Orders table
    @FXML private TableView<Order> ordersTable;
    @FXML private TableColumn<Order, Integer> colOrderId;
    @FXML private TableColumn<Order, LocalDate> colDate;
    @FXML private TableColumn<Order, String> colChannel;
    @FXML private TableColumn<Order, Double> colCost;
    @FXML private TableColumn<Order, Double> colPaid;
    @FXML private TableColumn<Order, String> colStatus;

    @FXML private ComboBox<String> searchByCombo;
    @FXML private TextField searchField;

    // Items table
    @FXML private TableView<OrderItem> itemsTable;
    @FXML private TableColumn<OrderItem, Integer> colProdId;
    @FXML private TableColumn<OrderItem, String> colProdName;
    @FXML private TableColumn<OrderItem, Integer> colQty;
    @FXML private TableColumn<OrderItem, Double> colPriceAt;
    @FXML private TableColumn<OrderItem, Double> colLineTotal;

    // Header form
    @FXML private TextField orderIdField;
    @FXML private DatePicker datePicker;
    @FXML private ComboBox<String> channelCombo;
    @FXML private ComboBox<String> statusCombo;
    @FXML private TextField amountPaidField;
    @FXML private TextField costField;
    @FXML private TextArea infoArea;

    @FXML private ComboBox<CustomerOption> customerCombo;
    @FXML private ComboBox<PaymentMethod> paymentMethodCombo;

    // Item add form
    @FXML private ComboBox<ProductOption> productCombo;
    @FXML private TextField qtyField;
    @FXML private TextField priceAtTimeField;

    // Buttons + status
    @FXML private Button confirmBtn;
    @FXML private Button cancelBtn;
    @FXML private Label statusLabel;

    private final ObservableList<Order> masterOrders = FXCollections.observableArrayList();
    private final ObservableList<Order> ordersList   = FXCollections.observableArrayList();
    private final ObservableList<OrderItem> currentItems = FXCollections.observableArrayList();

    private enum Mode { VIEW, INSERT, UPDATE }
    private Mode mode = Mode.VIEW;

    // -------- Wrappers for ComboBoxes --------
    public static class CustomerOption {
        final int id;
        final String label;
        CustomerOption(int id, String label) { this.id = id; this.label = label; }
        int getId() { return id; }
        @Override public String toString() { return label; }
    }

    public static class ProductOption {
        final int id;
        final String name;
        final double price;
        ProductOption(int id, String name, double price) { this.id = id; this.name = name; this.price = price; }
        int getId() { return id; }
        String getName() { return name; }
        double getPrice() { return price; }
        @Override public String toString() { return id + " - " + name + " ($" + price + ")"; }
    }

    @FXML
    public void initialize() {

        // Orders columns
        colOrderId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colChannel.setCellValueFactory(new PropertyValueFactory<>("channel"));
        colCost.setCellValueFactory(new PropertyValueFactory<>("cost"));
        colPaid.setCellValueFactory(new PropertyValueFactory<>("amountPaid"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("paymentStatus"));

        searchByCombo.setItems(FXCollections.observableArrayList("Order ID", "Customer ID", "Status"));
        searchByCombo.getSelectionModel().select("Order ID");

        ordersTable.setItems(ordersList);

        // Items columns
        colProdId.setCellValueFactory(new PropertyValueFactory<>("productId"));
        colProdName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        colQty.setCellValueFactory(new PropertyValueFactory<>("quantity"));
        colPriceAt.setCellValueFactory(new PropertyValueFactory<>("priceAtTime"));
        colLineTotal.setCellValueFactory(new PropertyValueFactory<>("lineTotal"));

        itemsTable.setItems(currentItems);

        channelCombo.setItems(FXCollections.observableArrayList("Online", "In store"));
        channelCombo.getSelectionModel().select("In store");

        statusCombo.setItems(FXCollections.observableArrayList("Pending", "Paid", "Failed", "Refunded"));
        statusCombo.getSelectionModel().select("Pending");

        costField.setEditable(false);
        orderIdField.setEditable(false);

        loadDropdowns();
        loadOrdersOnce();

        ordersTable.getSelectionModel().selectedItemProperty().addListener((obs, ov, order) -> {
            if (order != null) {
                fillHeaderForm(order);
                loadItemsFor(order.getId());
                setMode(Mode.VIEW);
            }
        });

        // auto fill priceAtTime when choosing product
        productCombo.valueProperty().addListener((obs, o, p) -> {
            if (p != null) priceAtTimeField.setText(String.valueOf(p.getPrice()));
        });

        clearAll();
        setMode(Mode.VIEW);
    }

    private void loadDropdowns() {
        try {
            // Customers
            List<Customer> customers = CustomerDAO.getAllCustomers();
            List<CustomerOption> opts = new ArrayList<>();
            opts.add(new CustomerOption(0, "(No Customer)"));
            for (Customer c : customers) {
                String label = c.getId() + " - " + c.getFirstName() + " " + c.getSecondName() + " (" + c.getEmail() + ")";
                opts.add(new CustomerOption(c.getId(), label));
            }
            customerCombo.setItems(FXCollections.observableArrayList(opts));
            customerCombo.getSelectionModel().selectFirst();

            // Payment Methods ✅ (fix function name)
            List<PaymentMethod> methods = PaymentMethodDAO.getPaymentMethodList();
            paymentMethodCombo.setItems(FXCollections.observableArrayList(methods));
            if (!methods.isEmpty()) paymentMethodCombo.getSelectionModel().selectFirst();

            // Products
            List<Product> products = ProductDAO.getAllProducts();
            List<ProductOption> popts = new ArrayList<>();
            for (Product p : products) popts.add(new ProductOption(p.getId(), p.getName(), p.getPrice()));
            productCombo.setItems(FXCollections.observableArrayList(popts));
            if (!popts.isEmpty()) productCombo.getSelectionModel().selectFirst();

        } catch (Exception e) {
            DBConnection.showError("Load error", e.getMessage());
            e.printStackTrace();
        }
    }

    private void loadOrdersOnce() {
        try {
            List<Order> all = OrderDAO.getAllOrders();
            masterOrders.setAll(all);
            ordersList.setAll(all);
            setStatus("Loaded " + all.size() + " orders.");
        } catch (Exception e) {
            DBConnection.showError("DB error", e.getMessage());
            setStatus("Failed to load orders.");
            e.printStackTrace();
        }
    }

    @FXML
    private void onSearch() {
        String by = searchByCombo.getValue();
        String key = (searchField.getText() == null) ? "" : searchField.getText().trim();

        List<Order> filtered = new ArrayList<>();
        for (Order o : masterOrders) {
            boolean ok;
            if ("Order ID".equals(by)) {
                ok = key.matches("\\d+") && o.getId() == Integer.parseInt(key);
            } else if ("Customer ID".equals(by)) {
                ok = key.matches("\\d+") && o.getCustomerId() != null && o.getCustomerId() == Integer.parseInt(key);
            } else if ("Status".equals(by)) {
                ok = o.getPaymentStatus() != null && o.getPaymentStatus().toLowerCase().contains(key.toLowerCase());
            } else ok = true;

            if (ok) filtered.add(o);
        }
        ordersList.setAll(filtered);
        setStatus("Filtered: " + filtered.size());
    }

    private void loadItemsFor(int orderId) {
        try {
            List<OrderItem> items = OrderDAO.getItems(orderId);
            currentItems.setAll(items);
            updateCostFieldFromItems();
        } catch (Exception e) {
            DBConnection.showError("Items load error", e.getMessage());
            e.printStackTrace();
        }
    }

    private void updateCostFieldFromItems() {
        double total = 0;
        for (OrderItem it : currentItems) total += it.getLineTotal();
        costField.setText(String.format("%.2f", total));
    }

    private void fillHeaderForm(Order o) {
        orderIdField.setText(String.valueOf(o.getId()));
        datePicker.setValue(o.getDate());
        channelCombo.getSelectionModel().select(o.getChannel());
        statusCombo.getSelectionModel().select(o.getPaymentStatus());
        amountPaidField.setText(String.format("%.2f", o.getAmountPaid()));
        infoArea.setText(o.getInformation() == null ? "" : o.getInformation());

        // customer
        if (o.getCustomerId() == null) customerCombo.getSelectionModel().selectFirst();
        else {
            for (CustomerOption opt : customerCombo.getItems()) {
                if (opt.getId() == o.getCustomerId()) { customerCombo.getSelectionModel().select(opt); break; }
            }
        }

        // payment method ✅ (fix getter name)
        if (o.getPaymentMethodId() != null) {
            for (PaymentMethod pm : paymentMethodCombo.getItems()) {
                if (pm.getID() == o.getPaymentMethodId()) { // ✅ getID()
                    paymentMethodCombo.getSelectionModel().select(pm);
                    break;
                }
            }
        }
    }

    private void clearAll() {
        ordersTable.getSelectionModel().clearSelection();
        orderIdField.clear();
        datePicker.setValue(LocalDate.now());
        channelCombo.getSelectionModel().select("In store");
        statusCombo.getSelectionModel().select("Pending");
        amountPaidField.setText("0.00");
        infoArea.clear();
        costField.setText("0.00");
        qtyField.setText("1");
        priceAtTimeField.clear();
        currentItems.clear();

        if (!customerCombo.getItems().isEmpty()) customerCombo.getSelectionModel().selectFirst();
        if (!paymentMethodCombo.getItems().isEmpty()) paymentMethodCombo.getSelectionModel().selectFirst();
        if (!productCombo.getItems().isEmpty()) productCombo.getSelectionModel().selectFirst();
    }

    private void setMode(Mode m) {
        mode = m;
        boolean editing = (m == Mode.INSERT || m == Mode.UPDATE);

        datePicker.setDisable(!editing);
        channelCombo.setDisable(!editing);
        statusCombo.setDisable(!editing);
        amountPaidField.setDisable(!editing);
        infoArea.setDisable(!editing);

        customerCombo.setDisable(!editing);
        paymentMethodCombo.setDisable(!editing);

        productCombo.setDisable(!editing);
        qtyField.setDisable(!editing);
        priceAtTimeField.setDisable(!editing);

        confirmBtn.setVisible(editing);
        confirmBtn.setManaged(editing);
        cancelBtn.setVisible(editing);
        cancelBtn.setManaged(editing);
    }

    private boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }

    private Integer selectedCustomerIdOrNull() {
        CustomerOption opt = customerCombo.getValue();
        if (opt == null || opt.getId() == 0) return null;
        return opt.getId();
    }

    private Integer selectedPaymentMethodIdOrNull() {
        PaymentMethod pm = paymentMethodCombo.getValue();
        return pm == null ? null : pm.getID(); // ✅ getID()
    }

    // ---------------- UI Buttons ----------------

    @FXML private void onInsert() { clearAll(); setMode(Mode.INSERT); setStatus("INSERT mode: add items then CONFIRM."); }
    @FXML private void onUpdate() {
        Order selected = ordersTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select an order first."); return; }
        setMode(Mode.UPDATE);
        setStatus("UPDATE mode: edit header/items then CONFIRM.");
    }

    @FXML
    private void onDelete() {
        Order selected = ordersTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select an order first."); return; }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Order");
        alert.setHeaderText("Delete order ID: " + selected.getId() + "?");
        alert.setContentText("This deletes items too.");

        if (alert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) { setStatus("Delete canceled."); return; }

        try {
            boolean ok = OrderDAO.deleteOrder(selected.getId());
            if (ok) {
                masterOrders.removeIf(o -> o.getId() == selected.getId());
                ordersList.removeIf(o -> o.getId() == selected.getId());
                clearAll();
                setMode(Mode.VIEW);
                setStatus("Deleted successfully.");
            } else setStatus("Delete failed.");
        } catch (Exception e) {
            DBConnection.showError("Delete error", e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML private void onRefresh() { loadOrdersOnce(); setMode(Mode.VIEW); setStatus("Orders refreshed."); }
    @FXML private void onClear() { clearAll(); setMode(Mode.VIEW); setStatus(""); }
    @FXML private void onCancel() { setMode(Mode.VIEW); setStatus("Canceled."); }

    @FXML
    private void onAddItem() {
        if (mode == Mode.VIEW) { setStatus("Switch to INSERT/UPDATE to edit items."); return; }

        ProductOption p = productCombo.getValue();
        if (p == null) { setStatus("Choose a product."); return; }

        int qty;
        double priceAt;
        try { qty = Integer.parseInt(qtyField.getText().trim()); }
        catch (Exception e) { setStatus("Quantity must be an integer."); return; }

        try { priceAt = Double.parseDouble(priceAtTimeField.getText().trim()); }
        catch (Exception e) { setStatus("Price_at_time must be a number."); return; }

        if (qty <= 0) { setStatus("Quantity must be > 0."); return; }
        if (priceAt < 0) { setStatus("Price_at_time must be >= 0."); return; }

        for (OrderItem it : currentItems) {
            if (it.getProductId() == p.getId()) {
                it.setQuantity(it.getQuantity() + qty);
                it.setPriceAtTime(priceAt);
                itemsTable.refresh();
                updateCostFieldFromItems();
                setStatus("Updated item quantity.");
                return;
            }
        }

        currentItems.add(new OrderItem(p.getId(), p.getName(), qty, priceAt)); // ✅ getName()
        updateCostFieldFromItems();
        setStatus("Item added.");
    }

    @FXML
    private void onRemoveItem() {
        if (mode == Mode.VIEW) { setStatus("Switch to INSERT/UPDATE to edit items."); return; }
        OrderItem selected = itemsTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select an item first."); return; }
        currentItems.remove(selected);
        updateCostFieldFromItems();
        setStatus("Item removed.");
    }

    @FXML private void onConfirm() { if (mode == Mode.INSERT) doInsert(); else if (mode == Mode.UPDATE) doUpdate(); }

    private void doInsert() {
        if (currentItems.isEmpty()) { setStatus("Add at least one item."); return; }
        LocalDate date = datePicker.getValue();
        if (date == null) { setStatus("Choose date."); return; }

        double paid;
        try { paid = Double.parseDouble(amountPaidField.getText().trim()); }
        catch (Exception e) { setStatus("Amount paid must be a number."); return; }

        Order header = new Order(
                date,
                channelCombo.getValue(),
                isBlank(infoArea.getText()) ? null : infoArea.getText().trim(),
                0,
                paid,
                statusCombo.getValue(),
                selectedCustomerIdOrNull(),
                selectedPaymentMethodIdOrNull()
        );

        try {
            int newId = OrderDAO.insertOrderWithItems(header, new ArrayList<>(currentItems));
            if (newId > 0) {
                Order inserted = new Order(newId, header.getDate(), header.getChannel(), header.getInformation(),
                        header.getCost(), header.getAmountPaid(), header.getPaymentStatus(),
                        header.getCustomerId(), header.getPaymentMethodId());

                masterOrders.add(0, inserted);
                ordersList.add(0, inserted);

                ordersTable.getSelectionModel().select(inserted);
                setMode(Mode.VIEW);
                setStatus("Inserted order ID = " + newId);
                loadItemsFor(newId);
            } else setStatus("Insert failed.");
        } catch (Exception e) {
            DBConnection.showError("Insert error", e.getMessage());
            e.printStackTrace();
        }
    }

    private void doUpdate() {
        Order selected = ordersTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select an order first."); return; }
        if (currentItems.isEmpty()) { setStatus("Order must have at least one item."); return; }

        LocalDate date = datePicker.getValue();
        if (date == null) { setStatus("Choose date."); return; }

        double paid;
        try { paid = Double.parseDouble(amountPaidField.getText().trim()); }
        catch (Exception e) { setStatus("Amount paid must be a number."); return; }

        Order header = new Order(
                selected.getId(),
                date,
                channelCombo.getValue(),
                isBlank(infoArea.getText()) ? null : infoArea.getText().trim(),
                0,
                paid,
                statusCombo.getValue(),
                selectedCustomerIdOrNull(),
                selectedPaymentMethodIdOrNull()
        );

        try {
            boolean ok = OrderDAO.updateOrderWithItems(header, new ArrayList<>(currentItems));
            if (ok) {
                List<Order> all = OrderDAO.getAllOrders();
                masterOrders.setAll(all);
                ordersList.setAll(all);

                for (Order o : ordersList) {
                    if (o.getId() == header.getId()) {
                        ordersTable.getSelectionModel().select(o);
                        fillHeaderForm(o);
                        break;
                    }
                }

                setMode(Mode.VIEW);
                setStatus("Updated successfully.");
            } else setStatus("Update failed.");

        } catch (Exception e) {
            DBConnection.showError("Update error", e.getMessage());
            e.printStackTrace();
        }
    }

    private void setStatus(String msg) {
        if (statusLabel != null) statusLabel.setText(msg);
    }
}

package com.example.database;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController {

    @FXML private TextField emailField;
    @FXML private PasswordField passwordField;
    @FXML private Label statusLabel;

    @FXML
    private void onLogin(ActionEvent event) {
        String email = emailField.getText() == null ? "" : emailField.getText().trim();
        String pass  = passwordField.getText() == null ? "" : passwordField.getText().trim();

        if (email.isEmpty() || pass.isEmpty()) {
            statusLabel.setText("Enter email and password.");
            return;
        }

        try {
            AuthDAO.StaffSession session = AuthDAO.loginStaff(email, pass);

            if (session == null) {
                statusLabel.setText("Invalid credentials or inactive staff.");
                return;
            }

            statusLabel.setText("Welcome " + session.role + ": " + session.fullName);

            // ✅ go to the dashboard shell
            SceneUtil.switchTo(event, "main_layout.fxml", "Book Store - " + session.role);

        } catch (Exception e) {
            statusLabel.setText("Login error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void onGoRegister(ActionEvent event) {
        SceneUtil.switchTo(event, "register.fxml", "Register");
    }
}

package com.example.database.DashBoard;

import com.example.database.DashboardDAO;
import com.example.database.Orders.Order;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.Locale;

public class HomeController {

    @FXML private Label customersLabel;
    @FXML private Label ordersLabel;
    @FXML private Label productsLabel;
    @FXML private Label suppliersLabel;
    @FXML private Label warehousesLabel;
    @FXML private Label revenueLabel;

    @FXML private Label statusLabel;
    @FXML private Label recentCountLabel;

    @FXML private TableView<Order> recentOrdersTable;
    @FXML private TableColumn<Order, Integer> colId;
    @FXML private TableColumn<Order, LocalDate> colDate;
    @FXML private TableColumn<Order, String> colChannel;
    @FXML private TableColumn<Order, Double> colCost;
    @FXML private TableColumn<Order, Double> colPaid;
    @FXML private TableColumn<Order, String> colStatus;

    private final ObservableList<Order> recent = FXCollections.observableArrayList();
    private final NumberFormat money = NumberFormat.getCurrencyInstance(Locale.US);

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colChannel.setCellValueFactory(new PropertyValueFactory<>("channel"));
        colCost.setCellValueFactory(new PropertyValueFactory<>("cost"));
        colPaid.setCellValueFactory(new PropertyValueFactory<>("amountPaid"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("paymentStatus"));

        colCost.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? "" : money.format(v));
            }
        });
        colPaid.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(Double v, boolean empty) {
                super.updateItem(v, empty);
                setText(empty || v == null ? "" : money.format(v));
            }
        });

        colStatus.setCellFactory(col -> new TableCell<>() {
            @Override protected void updateItem(String s, boolean empty) {
                super.updateItem(s, empty);
                getStyleClass().removeAll(
                        "status-pill-green", "status-pill-amber", "status-pill-red", "status-pill-gray"
                );
                if (empty || s == null) {
                    setText("");
                    return;
                }
                setText(s);
                String key = s.trim().toLowerCase();
                if (key.contains("paid")) getStyleClass().add("status-pill-green");
                else if (key.contains("pending")) getStyleClass().add("status-pill-amber");
                else if (key.contains("failed")) getStyleClass().add("status-pill-red");
                else getStyleClass().add("status-pill-gray");
            }
        });

        recentOrdersTable.setItems(recent);
        loadAll();
    }

    @FXML
    private void onRefresh() {
        loadAll();
    }

    private void loadAll() {
        setStatus("Loading…");

        Task<Void> task = new Task<>() {
            DashboardDAO.Stats stats;
            List<Order> rec;

            @Override
            protected Void call() {
                stats = DashboardDAO.loadStats();
                rec = DashboardDAO.recentOrders(12);
                return null;
            }

            @Override
            protected void succeeded() {
                customersLabel.setText(String.valueOf(stats.customers));
                ordersLabel.setText(String.valueOf(stats.orders));
                productsLabel.setText(String.valueOf(stats.products));
                if (suppliersLabel != null) suppliersLabel.setText(String.valueOf(stats.suppliers));
                if (warehousesLabel != null) warehousesLabel.setText(String.valueOf(stats.warehouses));
                revenueLabel.setText(money.format(stats.revenuePaid));

                recent.setAll(rec);
                if (recentCountLabel != null) recentCountLabel.setText("Latest " + rec.size());

                setStatus("Loaded");
            }

            @Override
            protected void failed() {
                setStatus("Failed to load dashboard");
                if (getException() != null) getException().printStackTrace();
            }
        };

        Thread th = new Thread(task);
        th.setDaemon(true);
        th.start();
    }

    private void setStatus(String msg) {
        if (statusLabel != null) statusLabel.setText(msg);
    }
}

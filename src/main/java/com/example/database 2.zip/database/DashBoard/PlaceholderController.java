package com.example.database.DashBoard;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class PlaceholderController {
    @FXML private Label titleLabel;
    @FXML private Label descLabel;
}

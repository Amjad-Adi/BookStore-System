package com.example.database.DashBoard;

import com.example.database.DashboardDAO;
import com.example.database.Orders.Order;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.concurrent.Task;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class DashboardController {

    @FXML private Label customersLabel;
    @FXML private Label ordersLabel;
    @FXML private Label productsLabel;
    @FXML private Label suppliersLabel;
    @FXML private Label warehousesLabel;
    @FXML private Label revenueLabel;

    @FXML private Label statusLabel;
    @FXML private Label recentCountLabel;

    @FXML private TableView<Order> recentOrdersTable;
    @FXML private TableColumn<Order, Integer> colId;
    @FXML private TableColumn<Order, Object> colDate;
    @FXML private TableColumn<Order, String> colChannel;
    @FXML private TableColumn<Order, Double> colCost;
    @FXML private TableColumn<Order, Double> colPaid;
    @FXML private TableColumn<Order, String> colStatus;

    private final ObservableList<Order> recent = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colDate.setCellValueFactory(new PropertyValueFactory<>("date"));
        colChannel.setCellValueFactory(new PropertyValueFactory<>("channel"));
        colCost.setCellValueFactory(new PropertyValueFactory<>("cost"));
        colPaid.setCellValueFactory(new PropertyValueFactory<>("amountPaid"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("paymentStatus"));

        recentOrdersTable.setItems(recent);
        loadAll();
    }

    @FXML
    private void onRefresh() {
        loadAll();
    }

    private void loadAll() {
        setStatus("Loading...");

        Task<Void> task = new Task<>() {
            DashboardDAO.Stats stats;
            List<Order> rec;

            @Override
            protected Void call() {
                stats = DashboardDAO.loadStats();
                rec = DashboardDAO.recentOrders(12);
                return null;
            }

            @Override
            protected void succeeded() {
                Platform.runLater(() -> {
                    customersLabel.setText(String.valueOf(stats.customers));
                    ordersLabel.setText(String.valueOf(stats.orders));
                    productsLabel.setText(String.valueOf(stats.products));
                    suppliersLabel.setText(String.valueOf(stats.suppliers));
                    warehousesLabel.setText(String.valueOf(stats.warehouses));
                    revenueLabel.setText(String.format("%.2f", stats.revenuePaid));

                    recent.setAll(rec);
                    recentCountLabel.setText("Showing " + rec.size() + " latest");

                    setStatus("Loaded");
                });
            }

            @Override
            protected void failed() {
                Platform.runLater(() -> setStatus("Failed to load dashboard"));
                getException().printStackTrace();
            }
        };

        Thread th = new Thread(task);
        th.setDaemon(true);
        th.start();
    }

    private void setStatus(String msg) {
        if (statusLabel != null) statusLabel.setText(msg == null ? "" : msg);
    }
}

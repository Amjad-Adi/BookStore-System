package com.example.database.DashBoard;

import com.example.database.SceneUtil;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.StackPane;

public class MainController {

    @FXML private ToggleGroup navGroup;

    @FXML private ToggleButton navDashboard;
    @FXML private ToggleButton navCustomers;
    @FXML private ToggleButton navOrders;
    @FXML private ToggleButton navProducts;
    @FXML private ToggleButton navSuppliers;
    @FXML private ToggleButton navWarehouses;
    @FXML private ToggleButton navPaymentPlans;
    @FXML private ToggleButton navStaff;

    @FXML private Label pageTitleLabel;
    @FXML private Label pageSubLabel;
    @FXML private Label globalStatusLabel;

    @FXML private StackPane contentPane;

    private String currentFxml  = "dashboard.fxml";
    private String currentTitle = "Dashboard";
    private String currentSub   = "Overview of your system";

    private static class NavItem {
        final String fxml, title, sub;
        NavItem(String fxml, String title, String sub) { this.fxml = fxml; this.title = title; this.sub = sub; }
    }

    @FXML
    public void initialize() {
        if (navGroup == null || contentPane == null) {
            throw new RuntimeException("FXML injection failed: navGroup/contentPane is null. Check fx:id + fx:controller.");
        }

        bind(navDashboard,    "dashboard.fxml",      "Dashboard",     "Overview of your system");
        bind(navCustomers,    "customers.fxml",      "Customers",     "Manage customers");
        bind(navOrders,       "orders-view.fxml",    "Orders",        "Manage transactions");
        bind(navProducts,     "products-view.fxml",  "Products",      "Manage product catalog");
        bind(navSuppliers,    "supllier.fxml",       "Suppliers",     "Manage suppliers");
        bind(navWarehouses,   "warehouse-view.fxml", "Warehouses",    "Manage storage");
        bind(navPaymentPlans, "payment_plan.fxml",   "Payment Plans", "Manage payment plans");
        bind(navStaff,        "placeholder.fxml",    "Staff",         "Manage staff");

        navGroup.selectedToggleProperty().addListener((obs, oldT, newT) -> {
            if (newT == null) {
                if (oldT != null) oldT.setSelected(true);
                return;
            }
            NavItem item = (NavItem) newT.getUserData();
            open(item.fxml, item.title, item.sub);
        });

        // default selection triggers listener
        navDashboard.setSelected(true);
    }

    private void bind(ToggleButton btn, String fxml, String title, String sub) {
        if (btn == null) return;
        btn.setUserData(new NavItem(fxml, title, sub));
        btn.setToggleGroup(navGroup); // extra safety
    }

    private void open(String fxml, String title, String sub) {
        try {
            SceneUtil.loadInto(contentPane, fxml);

            currentFxml = fxml;
            currentTitle = title;
            currentSub = sub;

            if (pageTitleLabel != null) pageTitleLabel.setText(title);
            if (pageSubLabel != null) pageSubLabel.setText(sub);
            setGlobalStatus("Loaded: " + title);

        } catch (Exception ex) {
            setGlobalStatus("Failed to open: " + fxml);
            ex.printStackTrace();
        }
    }

    @FXML
    private void onRefreshCurrent() {
        open(currentFxml, currentTitle, currentSub);
        setGlobalStatus("Refreshed: " + currentTitle);
    }

    private void setGlobalStatus(String msg) {
        if (globalStatusLabel != null) globalStatusLabel.setText(msg);
    }
}

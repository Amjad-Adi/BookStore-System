package com.example.database;

import com.example.database.Orders.Order;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class DashboardDAO {

    public static class Stats {
        public final int customers;
        public final int orders;
        public final int products;
        public final int suppliers;
        public final int warehouses;
        public final double revenuePaid;

        public Stats(int customers, int orders, int products, int suppliers, int warehouses, double revenuePaid) {
            this.customers = customers;
            this.orders = orders;
            this.products = products;
            this.suppliers = suppliers;
            this.warehouses = warehouses;
            this.revenuePaid = revenuePaid;
        }
    }

    public static Stats loadStats() {
        String qCustomers  = "SELECT COUNT(*) FROM Customers";
        String qOrders     = "SELECT COUNT(*) FROM `Transaction`";
        String qProducts   = "SELECT COUNT(*) FROM Product";
        String qSuppliers  = "SELECT COUNT(*) FROM Supplier";
        String qWarehouses = "SELECT COUNT(*) FROM Warehouse";
        String qRevenue    = "SELECT COALESCE(SUM(Amount_Paid),0) FROM `Transaction` WHERE Payment_Status='Paid'";

        try (Connection con = DBConnection.getConnection()) {
            int customers  = scalarInt(con, qCustomers);
            int orders     = scalarInt(con, qOrders);
            int products   = scalarInt(con, qProducts);
            int suppliers  = scalarInt(con, qSuppliers);
            int warehouses = scalarInt(con, qWarehouses);
            double revenuePaid = scalarDouble(con, qRevenue);

            return new Stats(customers, orders, products, suppliers, warehouses, revenuePaid);

        } catch (SQLException e) {
            throw new RuntimeException("loadStats failed: " + e.getMessage(), e);
        }
    }

    public static List<Order> recentOrders(int limit) {
        String sql = """
            SELECT Transaction_ID, Transaction_Date, Transaction_Channel, Transaction_Information,
                   Cost, Amount_Paid, Payment_Status, Customer_ID, Payment_Method_Id
            FROM `Transaction`
            ORDER BY Transaction_ID DESC
            LIMIT ?
        """;

        List<Order> list = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, limit);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Integer customerId = (Integer) rs.getObject("Customer_ID");
                    Integer paymentId  = (Integer) rs.getObject("Payment_Method_Id");

                    Date d = rs.getDate("Transaction_Date");
                    LocalDate date = (d == null) ? null : d.toLocalDate();

                    list.add(new Order(
                            rs.getInt("Transaction_ID"),
                            date,
                            rs.getString("Transaction_Channel"),
                            rs.getString("Transaction_Information"),
                            rs.getDouble("Cost"),
                            rs.getDouble("Amount_Paid"),
                            rs.getString("Payment_Status"),
                            customerId,
                            paymentId
                    ));
                }
            }

            return list;

        } catch (SQLException e) {
            throw new RuntimeException("recentOrders failed: " + e.getMessage(), e);
        }
    }

    private static int scalarInt(Connection con, String sql) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getInt(1) : 0;
        }
    }

    private static double scalarDouble(Connection con, String sql) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            return rs.next() ? rs.getDouble(1) : 0.0;
        }
    }
}

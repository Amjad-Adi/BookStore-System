package com.example.database.Products;

import com.example.database.DBConnection;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.ArrayList;
import java.util.List;

public class ProductController {

    // Table
    @FXML private TableView<Product> productTable;
    @FXML private TableColumn<Product, Integer> colId;
    @FXML private TableColumn<Product, String> colName;
    @FXML private TableColumn<Product, String> colDesc;
    @FXML private TableColumn<Product, String> colCategory;
    @FXML private TableColumn<Product, String> colCompany;
    @FXML private TableColumn<Product, Double> colPrice;

    // Form
    @FXML private TextField idField;
    @FXML private TextField nameField;
    @FXML private TextField descField;
    @FXML private ComboBox<String> categoryCombo;
    @FXML private TextField companyField;
    @FXML private TextField priceField;

    // Search bar
    @FXML private ComboBox<String> searchByCombo;
    @FXML private TextField searchField;

    // Buttons
    @FXML private Button confirmBtn;
    @FXML private Button cancelBtn;

    // Status
    @FXML private Label statusLabel;

    private final ObservableList<Product> masterList = FXCollections.observableArrayList();
    private final ObservableList<Product> tableList  = FXCollections.observableArrayList();

    private enum Mode { VIEW, INSERT, UPDATE }
    private Mode mode = Mode.VIEW;

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colName.setCellValueFactory(new PropertyValueFactory<>("name"));
        colDesc.setCellValueFactory(new PropertyValueFactory<>("description"));
        colCategory.setCellValueFactory(new PropertyValueFactory<>("category"));
        colCompany.setCellValueFactory(new PropertyValueFactory<>("company"));
        colPrice.setCellValueFactory(new PropertyValueFactory<>("price"));

        productTable.setItems(tableList);

        productTable.getSelectionModel().selectedItemProperty().addListener((obs, ov, p) -> {
            if (p != null) fillForm(p);
        });

        categoryCombo.setItems(FXCollections.observableArrayList("Book", "Stationery"));
        categoryCombo.getSelectionModel().select("Book");

        searchByCombo.setItems(FXCollections.observableArrayList("ID", "Name", "Category", "Company"));
        searchByCombo.getSelectionModel().select("Name");

        loadOnce();
        setMode(Mode.VIEW);
    }

    private void loadOnce() {
        try {
            List<Product> all = ProductDAO.getAllProducts();
            masterList.setAll(all);
            tableList.setAll(all);
            setStatus("Loaded " + all.size() + " products.");
        } catch (Exception e) {
            DBConnection.showError("DB error", e.getMessage());
            setStatus("Failed to load products.");
            e.printStackTrace();
        }
    }

    private void fillForm(Product p) {
        idField.setText(String.valueOf(p.getId()));
        nameField.setText(nullToEmpty(p.getName()));
        descField.setText(nullToEmpty(p.getDescription()));
        categoryCombo.getSelectionModel().select(p.getCategory());
        companyField.setText(nullToEmpty(p.getCompany()));
        priceField.setText(String.valueOf(p.getPrice()));
    }

    private void clearForm() {
        productTable.getSelectionModel().clearSelection();
        idField.clear();
        nameField.clear();
        descField.clear();
        categoryCombo.getSelectionModel().select("Book");
        companyField.clear();
        priceField.clear();
    }

    private void setMode(Mode m) {
        mode = m;
        boolean editing = (m == Mode.INSERT || m == Mode.UPDATE);

        idField.setDisable(true);
        nameField.setDisable(!editing);
        descField.setDisable(!editing);
        categoryCombo.setDisable(!editing);
        companyField.setDisable(!editing);
        priceField.setDisable(!editing);

        confirmBtn.setVisible(editing);
        confirmBtn.setManaged(editing);
        cancelBtn.setVisible(editing);
        cancelBtn.setManaged(editing);

        if (m == Mode.INSERT) clearForm();
    }

    private boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }
    private String nullToEmpty(String s) { return s == null ? "" : s; }

    private void setStatus(String msg) {
        if (statusLabel != null) statusLabel.setText(msg);
    }

    // ---------------- Top bar ----------------

    @FXML
    private void onSearch() {
        String by = searchByCombo.getValue();
        String key = (searchField.getText() == null) ? "" : searchField.getText().trim();

        List<Product> filtered = new ArrayList<>();

        for (Product p : masterList) {
            boolean ok;

            if ("ID".equals(by)) {
                ok = key.matches("\\d+") && p.getId() == Integer.parseInt(key);
            } else if ("Name".equals(by)) {
                ok = containsIgnoreCase(p.getName(), key);
            } else if ("Category".equals(by)) {
                ok = containsIgnoreCase(p.getCategory(), key);
            } else if ("Company".equals(by)) {
                ok = containsIgnoreCase(p.getCompany(), key);
            } else {
                ok = true;
            }

            if (ok) filtered.add(p);
        }

        tableList.setAll(filtered);
        setStatus("Filtered: " + filtered.size());
    }

    @FXML
    private void onRefresh() {
        tableList.setAll(masterList);
        setMode(Mode.VIEW);
        setStatus("Products refreshed.");
    }

    // ---------------- Buttons ----------------

    @FXML
    private void onInsert() {
        setMode(Mode.INSERT);
        setStatus("INSERT mode: fill fields then CONFIRM.");
    }

    @FXML
    private void onUpdate() {
        Product selected = productTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a product first."); return; }
        fillForm(selected);
        setMode(Mode.UPDATE);
        setStatus("UPDATE mode: edit then CONFIRM.");
    }

    @FXML
    private void onDelete() {
        Product selected = productTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a product first."); return; }

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Delete Product");
        alert.setHeaderText("Delete product ID: " + selected.getId() + "?");
        alert.setContentText("Are you sure?");

        if (alert.showAndWait().orElse(ButtonType.CANCEL) != ButtonType.OK) {
            setStatus("Delete canceled.");
            return;
        }

        try {
            boolean ok = ProductDAO.deleteProduct(selected.getId());
            if (ok) {
                masterList.removeIf(p -> p.getId() == selected.getId());
                tableList.removeIf(p -> p.getId() == selected.getId());
                clearForm();
                setMode(Mode.VIEW);
                setStatus("Deleted successfully.");
            } else setStatus("Delete failed.");
        } catch (Exception e) {
            DBConnection.showError("Delete error", e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void onClear() {
        clearForm();
        setMode(Mode.VIEW);
        setStatus("");
    }

    @FXML
    private void onConfirm() {
        if (mode == Mode.INSERT) doInsert();
        else if (mode == Mode.UPDATE) doUpdate();
    }

    @FXML
    private void onCancel() {
        setMode(Mode.VIEW);
        setStatus("Canceled.");
    }

    private void doInsert() {
        String name = nameField.getText();
        String desc = descField.getText();
        String category = categoryCombo.getValue();
        String company = companyField.getText();
        String priceStr = priceField.getText();

        if (isBlank(name) || isBlank(category) || isBlank(company) || isBlank(priceStr)) {
            setStatus("Fill: Name, Category, Company, Price.");
            return;
        }

        double price;
        try { price = Double.parseDouble(priceStr.trim()); }
        catch (Exception e) { setStatus("Price must be a number."); return; }

        try {
            Product p = new Product(name.trim(),
                    isBlank(desc) ? null : desc.trim(),
                    category,
                    company.trim(),
                    price);

            int newId = ProductDAO.insertProduct(p);

            if (newId > 0) {
                Product inserted = new Product(newId, p.getName(), p.getDescription(), p.getCategory(), p.getCompany(), p.getPrice());
                masterList.add(inserted);
                tableList.add(inserted);
                productTable.getSelectionModel().select(inserted);
                setMode(Mode.VIEW);
                setStatus("Inserted product ID = " + newId);
            } else setStatus("Insert failed.");

        } catch (Exception e) {
            DBConnection.showError("Insert error", e.getMessage());
            e.printStackTrace();
        }
    }

    private void doUpdate() {
        Product selected = productTable.getSelectionModel().getSelectedItem();
        if (selected == null) { setStatus("Select a product first."); return; }

        String name = nameField.getText();
        String desc = descField.getText();
        String category = categoryCombo.getValue();
        String company = companyField.getText();
        String priceStr = priceField.getText();

        if (isBlank(name) || isBlank(category) || isBlank(company) || isBlank(priceStr)) {
            setStatus("Fill: Name, Category, Company, Price.");
            return;
        }

        double price;
        try { price = Double.parseDouble(priceStr.trim()); }
        catch (Exception e) { setStatus("Price must be a number."); return; }

        try {
            Product updated = new Product(selected.getId(),
                    name.trim(),
                    isBlank(desc) ? null : desc.trim(),
                    category,
                    company.trim(),
                    price);

            boolean ok = ProductDAO.updateProduct(updated);

            if (ok) {
                for (int i = 0; i < masterList.size(); i++)
                    if (masterList.get(i).getId() == updated.getId()) { masterList.set(i, updated); break; }

                for (int i = 0; i < tableList.size(); i++)
                    if (tableList.get(i).getId() == updated.getId()) { tableList.set(i, updated); break; }

                productTable.getSelectionModel().select(updated);
                setMode(Mode.VIEW);
                setStatus("Updated successfully.");
            } else setStatus("Update failed.");

        } catch (Exception e) {
            DBConnection.showError("Update error", e.getMessage());
            e.printStackTrace();
        }
    }

    private boolean containsIgnoreCase(String value, String key) {
        if (key == null || key.isBlank()) return true;
        if (value == null) return false;
        return value.toLowerCase().contains(key.toLowerCase());
    }
}

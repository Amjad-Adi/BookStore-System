package com.example.database.Products;

public class Product {
    private int Product_ID;                 // Product_ID
    private String Product_Name;            // Product_Name
    private String Product_Description;     // Product_Description
    private String Product_Category;        // Product_Category
    private String Product_Company;         // Product_Company
    private double Product_Price;           // Product_Price

     // No id because there is an auto increment in the database
     public Product(String name, String description, String category, String company, double price) {
        this(0, name, description, category, company, price);
    }

    public Product(int id, String name, String description, String category, String company, double price) {
        this.Product_ID = id;
        this.Product_Name = name;
        this.Product_Description = description;
        this.Product_Category = category;
        this.Product_Company = company;
        this.Product_Price = price;
    }

    public int getId() { return Product_ID; }
    public String getName() { return Product_Name; }
    public String getDescription() { return Product_Description; }
    public String getCategory() { return Product_Category; }
    public String getCompany() { return Product_Company; }
    public double getPrice() { return Product_Price; }

    public void setName(String name) { this.Product_Name = name; }
    public void setDescription(String description) { this.Product_Description = description; }
    public void setCategory(String category) { this.Product_Category = category; }
    public void setCompany(String company) { this.Product_Company = company; }
    public void setPrice(double price) { this.Product_Price = price; }
}

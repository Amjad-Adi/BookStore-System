package com.example.database.Products;

import com.example.database.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDAO {

    public static List<Product> getAllProducts() {
        String sql = "SELECT * FROM Product ORDER BY Product_ID";
        List<Product> list = new ArrayList<>();

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(new Product(
                        rs.getInt("Product_ID"),
                        rs.getString("Product_Name"),
                        rs.getString("Product_Description"),
                        rs.getString("Product_Category"),
                        rs.getString("Product_Company"),
                        rs.getDouble("Product_Price")
                ));
            }
            return list;

        } catch (SQLException e) {
            throw new RuntimeException("getAllProducts failed: " + e.getMessage(), e);
        }
    }

    public static int insertProduct(Product p) {
        String sql = """
            INSERT INTO Product (Product_Name, Product_Description, Product_Category, Product_Company, Product_Price)
            VALUES (?, ?, ?, ?, ?)
            """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, p.getName());

            if (p.getDescription() != null)
                ps.setString(2, p.getDescription());
            else
                ps.setNull(2, Types.VARCHAR);

            ps.setString(3, p.getCategory());

            if (p.getCompany() != null)
                ps.setString(4, p.getCompany());
            else
                ps.setNull(4, Types.VARCHAR);

            ps.setDouble(5, p.getPrice());


            if (ps.executeUpdate() == 0) return -1;

            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getInt(1) : -1;
            }

        } catch (SQLException e) {
            throw new RuntimeException("insertProduct failed: " + e.getMessage(), e);
        }
    }

    public static boolean updateProduct(Product p) {
        String sql = """
        UPDATE Product
        SET Product_Name=?,
            Product_Description=?,
            Product_Category=?,
            Product_Company=?,
            Product_Price=?
        WHERE Product_ID=?
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, p.getName());

            if (p.getDescription() != null)
                ps.setString(2, p.getDescription());
            else
                ps.setNull(2, Types.VARCHAR);

            ps.setString(3, p.getCategory());

            if (p.getCompany() != null)
                ps.setString(4, p.getCompany());
            else
                ps.setNull(4, Types.VARCHAR);

            ps.setDouble(5, p.getPrice());
            ps.setInt(6, p.getId());

            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            throw new RuntimeException("updateProduct failed: " + e.getMessage(), e);
        }
    }


    public static boolean deleteProduct(int productId) {
        String sql = "DELETE FROM Product WHERE Product_ID=?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, productId);
            return ps.executeUpdate() == 1;

        } catch (SQLException e) {
            throw new RuntimeException("deleteProduct failed: " + e.getMessage(), e);
        }
    }
}

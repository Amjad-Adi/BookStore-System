package com.example.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class AuthDAO {

    public static class StaffSession {
        public final int staffId;
        public final String role;      // "Admin" or "Worker"
        public final String fullName;

        public StaffSession(int staffId, String role, String fullName) {
            this.staffId = staffId;
            this.role = role;
            this.fullName = fullName;
        }
    }

    public static StaffSession loginStaff(String email, String password) {
        String qStaff = """
            SELECT Staff_ID, First_Name, Last_Name
            FROM Staff
            WHERE Staff_Email=? AND Staff_Password=? AND Staff_Status='Active'
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(qStaff)) {

            ps.setString(1, email);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) return null;

                int id = rs.getInt("Staff_ID");
                String fullName = rs.getString("First_Name") + " " + rs.getString("Last_Name");

                // determine role
                String role = isAdmin(con, id) ? "Admin" : (isWorker(con, id) ? "Worker" : "Staff");

                return new StaffSession(id, role, fullName);
            }

        } catch (Exception e) {
            throw new RuntimeException("loginStaff failed: " + e.getMessage(), e);
        }
    }

    private static boolean isAdmin(Connection con, int staffId) throws Exception {
        try (PreparedStatement ps = con.prepareStatement("SELECT 1 FROM Admin WHERE Staff_ID=?")) {
            ps.setInt(1, staffId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }

    private static boolean isWorker(Connection con, int staffId) throws Exception {
        try (PreparedStatement ps = con.prepareStatement("SELECT 1 FROM Worker WHERE Staff_ID=?")) {
            ps.setInt(1, staffId);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }
}

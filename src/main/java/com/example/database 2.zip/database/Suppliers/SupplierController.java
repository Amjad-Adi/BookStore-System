package com.example.database.Suppliers;

import com.example.database.DBConnection;
import javafx.application.Platform;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import java.util.ArrayList;
import java.util.List;

import static javafx.collections.FXCollections.observableArrayList;

public class SupplierController{
    //Labels
    @FXML private Label supplierIDLabel;
    @FXML private Label supplierFirstNameLabel;
    @FXML private Label supplierSecondNameLabel;
    @FXML private Label supplierEmailLabel;
    @FXML private Label supplierStatusLabel;

    //Text Fields to show and modify data
    @FXML private TextField supplierIDField;
    @FXML private TextField supplierFirstNameField;
    @FXML private TextField supplierSecondNameField;
    @FXML private TextField supplierEmailField;
    @FXML private ComboBox<String> supplierStatusCombo;

    @FXML private Button confirmButton;
    @FXML private Button cancelButton;

    //Table and its columns
    @FXML private TableView<Supplier> supplierTable;
    @FXML private TableColumn<Supplier, Integer> supplierIDColumn;
    @FXML private TableColumn<Supplier, String> supplierFirstNameColumn;
    @FXML private TableColumn<Supplier, String> supplierSecondNameColumn;
    @FXML private TableColumn<Supplier, String> supplierEmailColumn;
    @FXML private TableColumn<Supplier, String> supplierStatusColumn;

    private final ObservableList<Supplier> supplierList = observableArrayList();
    private final ObservableList<Supplier> masterList   = observableArrayList();

    //show status
    @FXML private Label statusLabel;

    private enum Mode { VIEW, INSERT, UPDATE }
    private Mode mode = Mode.VIEW;

    private static final String ODD_ROW_COLOR    = "rgba(15,23,42,0.65)";
    private static final String EVEN_ROW_COLOR   = "rgba(2,6,23,0.65)";
    private static final String SELECT_TINT      = "rgba(56,189,248,0.22)";

    //Search
    @FXML private ComboBox<String> searchByCombo;
    @FXML private TextField searchField;

    @FXML
    public void initialize(){
        supplierTable.setItems(supplierList);
        supplierIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        supplierFirstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        supplierSecondNameColumn.setCellValueFactory(new PropertyValueFactory<>("secondName"));
        supplierEmailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        supplierStatusColumn.setCellValueFactory(new PropertyValueFactory<>("status"));

        supplierTable.setRowFactory(tv -> new TableRow<>() {
            @Override
            protected void updateItem(Supplier supplier, boolean empty) {
                super.updateItem(supplier, empty);
                if (empty || supplier == null) {
                    setStyle("");
                    return;
                }
                String baseColor = (getIndex() % 2 == 1) ? ODD_ROW_COLOR : EVEN_ROW_COLOR;
                if (isSelected()) {
                    setStyle("-fx-background-color: " + baseColor + ", " + SELECT_TINT + ";");
                } else {
                    setStyle("-fx-background-color: " + baseColor + ";");
                }
            }
        });

        supplierTable.setColumnResizePolicy(TableView.UNCONSTRAINED_RESIZE_POLICY);
        supplierIDColumn.setPrefWidth(80);
        supplierFirstNameColumn.setPrefWidth(200);
        supplierSecondNameColumn.setPrefWidth(200);
        supplierEmailColumn.setMinWidth(320);
        supplierEmailColumn.setPrefWidth(420);
        supplierStatusColumn.setPrefWidth(140);

        supplierTable.skinProperty().addListener((obs, o, n) -> supplierTable.lookupAll(".column-header .label").forEach(
                node -> node.setStyle("-fx-text-fill: #e5e7eb; -fx-font-weight: bold;")));

        supplierTable.getSelectionModel().selectedItemProperty().addListener((obs, ov, supplier) -> {
            if (supplier != null) fillForm(supplier);
        });

        supplierTable.skinProperty().addListener((obs, oldSkin, newSkin) -> {
            Platform.runLater(() -> {
                Node corner = supplierTable.lookup(".corner");
                if (corner != null) {
                    corner.setStyle(
                            "-fx-background-color: #020617;" +
                                    "-fx-border-color: #1e293b;" +
                                    "-fx-border-width: 0 0 1 1;"
                    );
                }

                Node filler = supplierTable.lookup(".filler");
                if (filler != null) {
                    filler.setStyle(
                            "-fx-background-color: #020617;" +
                                    "-fx-border-color: #1e293b;" +
                                    "-fx-border-width: 0 0 1 0;"
                    );
                }
            });
        });

        // ComboBox: white bg + black text + separators + hover highlight
        searchByCombo.setButtonCell(new ListCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty ? "" : item);
                setStyle("-fx-text-fill: black; -fx-background-color: white;");
            }
        });

        searchByCombo.setCellFactory(lv -> new ListCell<>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);

                if (empty || item == null) {
                    setText(null);
                    setStyle("");
                    return;
                }

                setText(item);
                setStyle("-fx-text-fill: black;" + "-fx-background-color: white;" + "-fx-padding: 8 10 8 10;" + "-fx-border-color: #e5e7eb;" + "-fx-border-width: 0 0 1 0;");
                hoverProperty().addListener((obs, was, isNow) -> {
                    if (isNow)
                        setStyle("-fx-text-fill: black;" + "-fx-background-color: #f1f5f9;" + "-fx-padding: 8 10 8 10;" + "-fx-border-color: #e5e7eb;" + "-fx-border-width: 0 0 1 0;");
                    else
                        setStyle("-fx-text-fill: black;" + "-fx-background-color: white;" + "-fx-padding: 8 10 8 10;" + "-fx-border-color: #e5e7eb;" + "-fx-border-width: 0 0 1 0;");
                });
            }
        });

        supplierStatusCombo.setItems(observableArrayList("Active", "Inactive"));
        supplierStatusCombo.getSelectionModel().select("Active");

        searchByCombo.setItems(observableArrayList("ID", "First name", "Last name", "Email", "Status"));
        searchByCombo.getSelectionModel().select("ID");

        supplierIDField.setEditable(false);
        supplierIDField.setFocusTraversable(false);

        setMode(Mode.VIEW);
        loadSuppliers();
    }

    private void fillForm(Supplier supplier) {
        supplierIDField.setText(String.valueOf(supplier.getId()));
        supplierFirstNameField.setText(supplier.getFirstName() == null ? "" : supplier.getFirstName());
        supplierSecondNameField.setText(supplier.getSecondName() == null ? "" : supplier.getSecondName());
        supplierEmailField.setText(supplier.getEmail() == null ? "" : supplier.getEmail());
        supplierStatusCombo.getSelectionModel().select(supplier.getStatus() == null ? "Active" : supplier.getStatus());
    }

    private void setMode(Mode mode) {
        this.mode = mode;
        setNode(supplierIDLabel, !(mode == Mode.INSERT));
        setNode(supplierIDField, !(mode == Mode.INSERT));
        ChangeTextFieldMode(!(mode == Mode.VIEW));
        setNode(confirmButton, !(mode == Mode.VIEW));
        setNode(cancelButton, !(mode == Mode.VIEW));
    }

    private void ChangeTextFieldMode(boolean editable){
        supplierFirstNameField.setEditable(editable);
        supplierSecondNameField.setEditable(editable);
        supplierEmailField.setEditable(editable);

        supplierFirstNameField.setFocusTraversable(editable);
        supplierSecondNameField.setFocusTraversable(editable);
        supplierEmailField.setFocusTraversable(editable);
        supplierStatusCombo.setFocusTraversable(editable);

        supplierFirstNameField.setDisable(false);
        supplierSecondNameField.setDisable(false);
        supplierEmailField.setDisable(false);
        supplierStatusCombo.setDisable(false);

        supplierStatusCombo.setMouseTransparent(!editable);
    }

    private void setNode(Control c, boolean visible) {
        c.setVisible(visible);
        c.setManaged(visible);
    }

    private void loadSuppliers() {
        try {
            ArrayList<Supplier> suppliers = SupplierDAO.getSupplierList();
            masterList.setAll(suppliers);
            supplierList.setAll(suppliers);
            statusLabel.setText("Loaded " + supplierList.size() + " suppliers.");
            supplierTable.refresh();
        } catch (Exception e) {
            DBConnection.showError("Database error", e.getMessage());
            statusLabel.setText("Failed to load suppliers.");
            e.printStackTrace();
        }
    }

    @FXML
    private void onInsert() {
        clearForm();
        supplierStatusCombo.getSelectionModel().select("Active");
        setMode(Mode.INSERT);
        statusLabel.setText("INSERT mode: fill fields then CONFIRM.");
    }

    private void insertSupplier() {
        try {
            if (supplierFirstNameField.getText() == null || supplierFirstNameField.getText().trim().isEmpty()) {
                statusLabel.setText("First name is required.");
                return;
            }
            if (supplierSecondNameField.getText() == null || supplierSecondNameField.getText().trim().isEmpty()) {
                statusLabel.setText("Last name is required.");
                return;
            }
            if (supplierEmailField.getText() == null || supplierEmailField.getText().trim().isEmpty()) {
                statusLabel.setText("Email is required.");
                return;
            }
            if (!supplierEmailField.getText().trim().matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                statusLabel.setText("Invalid email format.");
                return;
            }

            Supplier newSupplier = new Supplier(
                    0,
                    supplierFirstNameField.getText().trim(),
                    supplierSecondNameField.getText().trim(),
                    supplierEmailField.getText().trim(),
                    supplierStatusCombo.getValue()
            );

            int newId = SupplierDAO.insertSupplier(newSupplier);
            if (newId > 0) {
                Supplier inserted = new Supplier(newId, newSupplier.getFirstName(), newSupplier.getSecondName(), newSupplier.getEmail(), newSupplier.getStatus());
                masterList.add(inserted);
                supplierList.add(inserted);
                supplierTable.getSelectionModel().select(inserted);
                setMode(Mode.VIEW);
                statusLabel.setText("Inserted supplier ID = " + newId);
            } else {
                statusLabel.setText("Insert failed.");
            }
        } catch (Exception e) {
            DBConnection.showError("Insert error", e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void onUpdate() {
        Supplier selected = supplierTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            statusLabel.setText("Select a supplier first.");
        }
        else {
            fillForm(selected);
            setMode(Mode.UPDATE);
            statusLabel.setText("UPDATE mode: edit fields then CONFIRM.");
        }
    }

    private void updateSupplier() {
        Supplier selected = supplierTable.getSelectionModel().getSelectedItem();
        if (selected == null)
            statusLabel.setText("Select a supplier first.");
        else {
            try {
                if (supplierFirstNameField.getText() == null || supplierFirstNameField.getText().trim().isEmpty()) {
                    statusLabel.setText("First name is required.");
                    return;
                }
                if (supplierSecondNameField.getText() == null || supplierSecondNameField.getText().trim().isEmpty()) {
                    statusLabel.setText("Last name is required.");
                    return;
                }
                if (supplierEmailField.getText() == null || supplierEmailField.getText().trim().isEmpty()) {
                    statusLabel.setText("Email is required.");
                    return;
                }
                if (!supplierEmailField.getText().trim().matches("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$")) {
                    statusLabel.setText("Invalid email format.");
                    return;
                }

                Supplier updatedSupplier = new Supplier(
                        Integer.parseInt(supplierIDField.getText().trim()),
                        supplierFirstNameField.getText().trim(),
                        supplierSecondNameField.getText().trim(),
                        supplierEmailField.getText().trim(),
                        supplierStatusCombo.getValue()
                );

                SupplierDAO.updateSupplier(updatedSupplier);
                replaceInLists(updatedSupplier);
                supplierTable.getSelectionModel().select(updatedSupplier);
                setMode(Mode.VIEW);
                statusLabel.setText("Updated successfully.");
            } catch (Exception e) {
                DBConnection.showError("Update error", e.getMessage());
                e.printStackTrace();
            }
        }
    }

    @FXML
    private void onToggleStatus() {
        Supplier selected = supplierTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            statusLabel.setText("Select a supplier first.");
            return;
        }
        try {
            String newStatus = "Active".equalsIgnoreCase(selected.getStatus()) ? "Inactive" : "Active";
            SupplierDAO.setSupplierStatus(selected.getId(), newStatus);
            Supplier updated = new Supplier(selected.getId(), selected.getFirstName(), selected.getSecondName(), selected.getEmail(), newStatus);
            replaceInLists(updated);
            supplierTable.getSelectionModel().select(updated);
            supplierTable.refresh();
            statusLabel.setText("Status changed to " + newStatus + ".");
        } catch (Exception e) {
            DBConnection.showError("Update error", e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML
    private void onConfirm() {
        if (mode == Mode.INSERT) {
            insertSupplier();
        } else if (mode == Mode.UPDATE) {
            updateSupplier();
        }
    }

    @FXML
    private void onCancel() {
        setMode(Mode.VIEW);
        statusLabel.setText("Canceled.");
    }

    @FXML
    private void onSearch() {
        String searchStandard = searchByCombo.getValue();
        String key = (searchField.getText() == null) ? "" : searchField.getText().trim();
        List<Supplier> filtered = new ArrayList<>();

        for (Supplier supplier : masterList) {
            boolean ok = false;

            if ("ID".equals(searchStandard)) {
                ok = key.matches("\\d+") && supplier.getId() == Integer.parseInt(key);
            }
            else if ("First name".equals(searchStandard)) {
                ok = supplier.getFirstName() != null && supplier.getFirstName().equalsIgnoreCase(key);
            }
            else if ("Last name".equals(searchStandard)) {
                ok = supplier.getSecondName() != null && supplier.getSecondName().equalsIgnoreCase(key);
            }
            else if ("Email".equals(searchStandard)) {
                ok = supplier.getEmail() != null && supplier.getEmail().equalsIgnoreCase(key);
            }
            else if ("Status".equals(searchStandard)) {
                ok = supplier.getStatus() != null && supplier.getStatus().equalsIgnoreCase(key);
            }

            if (ok)
                filtered.add(supplier);
        }

        supplierList.setAll(filtered);
        statusLabel.setText("Filtered: " + filtered.size());
        supplierTable.refresh();
    }

    @FXML
    private void onRefresh() {
        supplierList.setAll(masterList);
        setMode(Mode.VIEW);
        statusLabel.setText("Suppliers refreshed");
        supplierTable.refresh();
    }

    private void clearForm() {
        supplierTable.getSelectionModel().clearSelection();
        supplierIDField.clear();
        supplierFirstNameField.clear();
        supplierSecondNameField.clear();
        supplierEmailField.clear();
        supplierStatusCombo.getSelectionModel().select("Active");
    }

    @FXML
    private void onClear() {
        clearForm();
        setMode(Mode.VIEW);
        statusLabel.setText("");
    }

    private void replaceInLists(Supplier updatedSupplier) {
        for (int i = 0; i < masterList.size(); i++) {
            if (masterList.get(i).getId() == updatedSupplier.getId()) {
                masterList.set(i, updatedSupplier);
                break;
            }
        }
        for (int i = 0; i < supplierList.size(); i++) {
            if (supplierList.get(i).getId() == updatedSupplier.getId()) {
                supplierList.set(i, updatedSupplier);
                break;
            }
        }
    }
}

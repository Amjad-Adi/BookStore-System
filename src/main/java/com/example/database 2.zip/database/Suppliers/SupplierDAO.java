package com.example.database.Suppliers;

import com.example.database.DBConnection;

import java.sql.*;
import java.util.*;

public class SupplierDAO {
    public static ArrayList<Supplier> getSupplierList() {
        String sql = "Select * from Supplier order by Supplier_ID";
        try (Connection databaseConnection = DBConnection.getConnection();
             PreparedStatement preparedStatement = databaseConnection.prepareStatement(sql);
             ResultSet sqlExecutionResult = preparedStatement.executeQuery()) {
            ArrayList<Supplier> list = new ArrayList<>();
            while (sqlExecutionResult.next()) {
                list.add(new Supplier(
                        sqlExecutionResult.getInt("Supplier_ID"),
                        sqlExecutionResult.getString("Supplier_First_Name"),
                        sqlExecutionResult.getString("Supplier_Last_Name"),
                        sqlExecutionResult.getString("Supplier_Email"),
                        sqlExecutionResult.getString("Supplier_Status")
                ));
            }
            return list;
        } catch (SQLException e) {
            throw new RuntimeException("getting Supplier List failed: " + e.getMessage(), e);
        }
    }

    public static int insertSupplier(Supplier supplier) {
        String sql = """
            Insert into Supplier (Supplier_First_Name, Supplier_Last_Name, Supplier_Email, Supplier_Status)
            values(?,?,?,?)""";
        try (Connection databaseConnection = DBConnection.getConnection();
             PreparedStatement preparedStatement = databaseConnection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            preparedStatement.setString(1, supplier.getFirstName().trim());
            preparedStatement.setString(2, supplier.getSecondName().trim());
            preparedStatement.setString(3, supplier.getEmail().trim());
            preparedStatement.setString(4, (supplier.getStatus() == null || supplier.getStatus().trim().isEmpty()) ? "Active" : supplier.getStatus().trim());

            if (preparedStatement.executeUpdate() == 0) return -1;
            try (ResultSet keys = preparedStatement.getGeneratedKeys()) {
                return keys.next() ? keys.getInt(1) : -1;
            }
        } catch (SQLIntegrityConstraintViolationException dup) {
            throw new RuntimeException("Supplier email already exists.");
        } catch (SQLException e) {
            throw new RuntimeException("Inserting Supplier failed: " + e.getMessage(), e);
        }
    }

    public static void updateSupplier(Supplier supplier) {
        String sql = """
            UPDATE Supplier
            SET Supplier_First_Name=?,
                Supplier_Last_Name=?,
                Supplier_Email=?,
                Supplier_Status=?
            WHERE Supplier_ID=?""";
        try (Connection databaseConnection = DBConnection.getConnection();
             PreparedStatement preparedStatement = databaseConnection.prepareStatement(sql)) {
            preparedStatement.setString(1, supplier.getFirstName().trim());
            preparedStatement.setString(2, supplier.getSecondName().trim());
            preparedStatement.setString(3, supplier.getEmail().trim());
            preparedStatement.setString(4, supplier.getStatus().trim());
            preparedStatement.setInt(5, supplier.getId());
            preparedStatement.executeUpdate();
        } catch (SQLIntegrityConstraintViolationException dup) {
            throw new RuntimeException("Supplier email already exists.");
        } catch (SQLException e) {
            throw new RuntimeException("updateSupplier failed: " + e.getMessage(), e);
        }
    }

    public static void setSupplierStatus(int supplierId, String status) {
        String sql = "UPDATE Supplier SET Supplier_Status=? WHERE Supplier_ID=?";
        try (Connection databaseConnection = DBConnection.getConnection();
             PreparedStatement preparedStatement = databaseConnection.prepareStatement(sql)) {
            preparedStatement.setString(1, status);
            preparedStatement.setInt(2, supplierId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("setSupplierStatus failed: " + e.getMessage(), e);
        }
    }
}

